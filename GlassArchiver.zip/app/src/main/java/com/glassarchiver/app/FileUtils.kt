package com.glassarchiver.app

import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun listDir(dir: File, s: AppSettings): List<File> {
    val all = dir.listFiles()?.toList() ?: emptyList()
    val visible = if (s.showHidden) all else all.filter { !it.name.startsWith(".") }
    val cmp: Comparator<File> = when (s.sortMode) {
        1 -> compareByDescending<File> { it.length() }
        2 -> compareByDescending<File> { it.lastModified() }
        else -> compareBy<File> { it.name.lowercase() }
    }
    val sorted = visible.sortedWith(cmp)
    return if (s.foldersFirst) sorted.sortedBy { if (it.isDirectory) 0 else 1 } else sorted
}

fun formatSize(b: Long): String {
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

fun formatDate(t: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(t))

fun uniqueFile(dir: File, name: String): File {
    var target = File(dir, name)
    if (!target.exists()) return target
    val base = name.substringBefore('.', name)
    val ext = if (name.contains('.')) "." + name.substringAfter('.') else ""
    var n = 1
    while (target.exists()) { target = File(dir, "$base ($n)$ext"); n++ }
    return target
}

fun pasteInto(dir: File, files: List<File>, cut: Boolean) {
    for (f in files) {
        if (f.isDirectory && (dir.canonicalPath + "/").startsWith(f.canonicalPath + "/")) {
            throw IOException("Can't paste a folder into itself")
        }
        val target = uniqueFile(dir, f.name)
        if (cut) {
            if (!f.renameTo(target)) {
                f.copyRecursively(target)
                f.deleteRecursively()
            }
        } else {
            f.copyRecursively(target)
        }
    }
}

fun openFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, f.name))
    } catch (e: Exception) {
        Toast.makeText(ctx, e.message ?: "Can't open file", Toast.LENGTH_LONG).show()
    }
}
