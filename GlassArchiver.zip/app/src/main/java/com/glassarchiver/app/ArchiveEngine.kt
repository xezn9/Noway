package com.glassarchiver.app

import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream
import org.apache.commons.compress.archivers.zip.ZipFile
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

object ArchiveEngine {

    data class Entry(val name: String, val size: Long, val isDir: Boolean)

    fun kind(lowerName: String): String? = when {
        lowerName.endsWith(".7z") -> "7z"
        lowerName.endsWith(".zip") || lowerName.endsWith(".jar") ||
            lowerName.endsWith(".apk") || lowerName.endsWith(".cbz") -> "zip"
        lowerName.endsWith(".tar.gz") || lowerName.endsWith(".tgz") -> "tgz"
        lowerName.endsWith(".tar.bz2") || lowerName.endsWith(".tbz2") || lowerName.endsWith(".tbz") -> "tbz"
        lowerName.endsWith(".tar.xz") || lowerName.endsWith(".txz") -> "txz"
        lowerName.endsWith(".tar") -> "tar"
        lowerName.endsWith(".gz") -> "gz"
        lowerName.endsWith(".bz2") -> "bz2"
        lowerName.endsWith(".xz") -> "xz"
        else -> null
    }

    fun baseName(file: File): String {
        val n = file.name
        val l = n.lowercase()
        val suffixes = listOf(".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tbz2", ".tbz", ".txz")
        for (s in suffixes) if (l.endsWith(s)) return n.dropLast(s.length)
        return n.substringBeforeLast('.', n)
    }

    private fun isSingle(k: String) = k == "gz" || k == "bz2" || k == "xz"

    private fun tarStream(f: File, k: String): TarArchiveInputStream {
        val raw = BufferedInputStream(FileInputStream(f))
        val s: InputStream = when (k) {
            "tgz" -> GzipCompressorInputStream(raw)
            "tbz" -> BZip2CompressorInputStream(raw)
            "txz" -> XZCompressorInputStream(raw)
            else -> raw
        }
        return TarArchiveInputStream(s)
    }

    private fun singleStream(f: File, k: String): InputStream {
        val raw = BufferedInputStream(FileInputStream(f))
        return when (k) {
            "gz" -> GzipCompressorInputStream(raw)
            "bz2" -> BZip2CompressorInputStream(raw)
            else -> XZCompressorInputStream(raw)
        }
    }

    fun list(file: File): List<Entry> {
        val k = kind(file.name.lowercase()) ?: throw IOException("Unsupported archive (RAR is not supported)")
        val res = mutableListOf<Entry>()
        when {
            k == "7z" -> SevenZFile.builder().setFile(file).get().use { sz ->
                for (e in sz.entries) res += Entry(e.name, e.size, e.isDirectory)
            }
            k == "zip" -> ZipFile.builder().setFile(file).get().use { z ->
                for (e in z.entries.asSequence()) res += Entry(e.name, e.size, e.isDirectory)
            }
            isSingle(k) -> res += Entry(baseName(file), file.length(), false)
            else -> tarStream(file, k).use { s ->
                while (true) {
                    val e = s.nextEntry ?: break
                    res += Entry(e.name, e.size, e.isDirectory)
                }
            }
        }
        return res
    }

    private fun safeTarget(dest: File, name: String): File {
        val t = File(dest, name)
        val root = dest.canonicalPath
        val c = t.canonicalPath
        if (c != root && !c.startsWith(root + File.separator)) throw IOException("Blocked unsafe path: $name")
        return t
    }

    private fun writeOut(t: File, input: InputStream) {
        t.parentFile?.mkdirs()
        FileOutputStream(t).use { input.copyTo(it, 65536) }
    }

    fun extract(file: File, dest: File) {
        val k = kind(file.name.lowercase()) ?: throw IOException("Unsupported archive (RAR is not supported)")
        dest.mkdirs()
        when {
            k == "7z" -> SevenZFile.builder().setFile(file).get().use { sz ->
                var e = sz.nextEntry
                while (e != null) {
                    val t = safeTarget(dest, e.name)
                    if (e.isDirectory) {
                        t.mkdirs()
                    } else {
                        t.parentFile?.mkdirs()
                        FileOutputStream(t).use { out ->
                            val buf = ByteArray(65536)
                            while (true) {
                                val n = sz.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                            }
                        }
                    }
                    e = sz.nextEntry
                }
            }
            k == "zip" -> ZipFile.builder().setFile(file).get().use { z ->
                for (e in z.entries.asSequence()) {
                    val t = safeTarget(dest, e.name)
                    if (e.isDirectory) t.mkdirs() else z.getInputStream(e).use { writeOut(t, it) }
                }
            }
            isSingle(k) -> singleStream(file, k).use { writeOut(safeTarget(dest, baseName(file)), it) }
            else -> tarStream(file, k).use { s ->
                while (true) {
                    val e = s.nextEntry ?: break
                    if (e.isSymbolicLink || e.isLink) continue
                    val t = safeTarget(dest, e.name)
                    if (e.isDirectory) t.mkdirs() else writeOut(t, s)
                }
            }
        }
    }

    fun extensionFor(fmt: String) = when (fmt) {
        "7z" -> "7z"
        "tar" -> "tar"
        "tgz" -> "tar.gz"
        else -> "zip"
    }

    fun create(files: List<File>, out: File, fmt: String, level: Int) {
        val items = mutableListOf<Pair<File, String>>()
        fun add(f: File, prefix: String) {
            val name = prefix + f.name
            items += f to name
            if (f.isDirectory) f.listFiles()?.forEach { add(it, "$name/") }
        }
        files.forEach { add(it, "") }

        when (fmt) {
            "zip" -> ZipArchiveOutputStream(out).use { z ->
                z.setLevel(level)
                for ((f, n) in items) {
                    z.putArchiveEntry(ZipArchiveEntry(f, n))
                    if (f.isFile) FileInputStream(f).use { it.copyTo(z) }
                    z.closeArchiveEntry()
                }
            }
            "7z" -> SevenZOutputFile(out).use { s ->
                for ((f, n) in items) {
                    s.putArchiveEntry(s.createArchiveEntry(f, n))
                    if (f.isFile) FileInputStream(f).use { ins ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            s.write(buf, 0, r)
                        }
                    }
                    s.closeArchiveEntry()
                }
            }
            else -> {
                val os: OutputStream = BufferedOutputStream(FileOutputStream(out))
                val wrapped: OutputStream = if (fmt == "tgz") GzipCompressorOutputStream(os) else os
                TarArchiveOutputStream(wrapped).use { t ->
                    t.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
                    t.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
                    for ((f, n) in items) {
                        t.putArchiveEntry(TarArchiveEntry(f, n))
                        if (f.isFile) FileInputStream(f).use { it.copyTo(t) }
                        t.closeArchiveEntry()
                    }
                }
            }
        }
    }
}
