package com.glassarchiver.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
fun SettingsScreen(s: AppSettings, padding: PaddingValues) {
    LazyColumn(
        contentPadding = PaddingValues(
            start = 12.dp, end = 12.dp,
            top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding()
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card("Theme") {
                RadioRow("System", s.theme == 0) { s.setTheme(0) }
                RadioRow("Light", s.theme == 1) { s.setTheme(1) }
                RadioRow("Dark", s.theme == 2) { s.setTheme(2) }
            }
        }
        item {
            Card("File list") {
                SwitchRow("Show hidden files", s.showHidden) { s.setShowHidden(it) }
                SwitchRow("Folders first", s.foldersFirst) { s.setFoldersFirst(it) }
                SwitchRow("Confirm before delete", s.confirmDelete) { s.setConfirmDelete(it) }
            }
        }
        item {
            Card("Sort by") {
                RadioRow("Name", s.sortMode == 0) { s.setSortMode(0) }
                RadioRow("Size", s.sortMode == 1) { s.setSortMode(1) }
                RadioRow("Date", s.sortMode == 2) { s.setSortMode(2) }
            }
        }
        item {
            Card("Compression") {
                listOf("zip" to "zip", "7z" to "7z", "tar" to "tar", "tgz" to "tar.gz").forEach { (code, label) ->
                    RadioRow("Default format: $label", s.format == code) { s.setFormat(code) }
                }
                Text("Default level: ${s.level}")
                Slider(
                    value = s.level.toFloat(),
                    onValueChange = { s.setLevel(it.roundToInt()) },
                    valueRange = 1f..9f,
                    steps = 7
                )
            }
        }
        item {
            Card("About") {
                Text("Glass Archiver 1.0")
                Text("Liquid glass UI powered by the Backdrop library.", fontSize = 12.sp)
                Text("Formats: zip, 7z, tar, tar.gz, tar.bz2, tar.xz, gz, bz2, xz", fontSize = 12.sp)
            }
        }
    }
}
