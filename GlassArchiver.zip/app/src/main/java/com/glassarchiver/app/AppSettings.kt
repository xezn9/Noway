package com.glassarchiver.app

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class AppSettings(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme by mutableIntStateOf(sp.getInt("theme", 0)); private set          // 0 system, 1 light, 2 dark
    var showHidden by mutableStateOf(sp.getBoolean("hidden", false)); private set
    var foldersFirst by mutableStateOf(sp.getBoolean("folders_first", true)); private set
    var sortMode by mutableIntStateOf(sp.getInt("sort", 0)); private set        // 0 name, 1 size, 2 date
    var confirmDelete by mutableStateOf(sp.getBoolean("confirm_delete", true)); private set
    var level by mutableIntStateOf(sp.getInt("level", 5)); private set
    var format by mutableStateOf(sp.getString("format", "zip") ?: "zip"); private set

    fun setTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun setShowHidden(v: Boolean) { showHidden = v; sp.edit().putBoolean("hidden", v).apply() }
    fun setFoldersFirst(v: Boolean) { foldersFirst = v; sp.edit().putBoolean("folders_first", v).apply() }
    fun setSortMode(v: Int) { sortMode = v; sp.edit().putInt("sort", v).apply() }
    fun setConfirmDelete(v: Boolean) { confirmDelete = v; sp.edit().putBoolean("confirm_delete", v).apply() }
    fun setLevel(v: Int) { level = v; sp.edit().putInt("level", v).apply() }
    fun setFormat(v: String) { format = v; sp.edit().putString("format", v).apply() }
}

@Composable
fun AppTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = if (dark) {
        darkColorScheme(
            primary = Color(0xFF8B93FF),
            background = Color(0xFF0F1016),
            surface = Color(0xFF1B1C25),
            onBackground = Color(0xFFEDEEF5),
            onSurface = Color(0xFFEDEEF5)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF4F5BFF),
            background = Color(0xFFF1F2F8),
            surface = Color(0xFFFFFFFF),
            onBackground = Color(0xFF15161C),
            onSurface = Color(0xFF15161C)
        )
    }
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            content()
        }
    }
}
