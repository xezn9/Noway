package com.glassarchiver.app

import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

sealed interface Dlg {
    data class ArchiveMenu(val file: File) : Dlg
    data class Contents(val file: File, val entries: List<ArchiveEngine.Entry>) : Dlg
    data object NewFolder : Dlg
    data class Rename(val file: File) : Dlg
    data class Delete(val files: List<File>) : Dlg
    data class Compress(val files: List<File>) : Dlg
}

private class Act(val glyph: String, val label: String, val onClick: () -> Unit)

@Composable
fun FileRow(f: File, selected: Boolean, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val isArchive = ArchiveEngine.kind(f.name.lowercase()) != null
    val glyph = when {
        f.isDirectory -> "📁"
        isArchive -> "🗜️"
        else -> "📄"
    }
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) cs.primary.copy(alpha = 0.25f) else cs.surface)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(glyph, fontSize = 26.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            val sub = if (f.isDirectory) formatDate(f.lastModified()) else formatSize(f.length()) + "  ·  " + formatDate(f.lastModified())
            Text(sub, fontSize = 12.sp, color = cs.onSurface.copy(alpha = 0.6f))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileManagerApp(settings: AppSettings) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val root = remember { Environment.getExternalStorageDirectory() }
    var dir by remember { mutableStateOf(root) }
    var tick by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf(setOf<File>()) }
    var clip by remember { mutableStateOf<List<File>>(emptyList()) }
    var clipCut by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    val backdrop = rememberLayerBackdrop()

    val files = remember(dir, tick, settings.showHidden, settings.sortMode, settings.foldersFirst) {
        listDir(dir, settings)
    }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()

    fun task(label: String, block: () -> Unit) {
        scope.launch {
            busy = label
            try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: Exception) {
                toast(e.message ?: e.toString())
            }
            busy = null
            selected = emptySet()
            tick++
        }
    }

    fun goUp() {
        val p = dir.parentFile
        if (dir != root && p != null) dir = p
    }

    BackHandler(enabled = selected.isNotEmpty() || showSettings || dir != root) {
        when {
            selected.isNotEmpty() -> selected = emptySet()
            showSettings -> showSettings = false
            else -> goUp()
        }
    }

    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(Modifier.fillMaxSize()) {
        // ---- content (captured by the backdrop so the glass can refract it) ----
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(backdrop)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (showSettings) {
                SettingsScreen(settings, PaddingValues(top = top + 84.dp, bottom = bottom + 100.dp))
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = top + 84.dp, bottom = bottom + 110.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (files.isEmpty()) {
                        item { Text("Empty folder", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)) }
                    }
                    items(files, key = { it.absolutePath }) { f ->
                        FileRow(
                            f, f in selected,
                            Modifier.combinedClickable(
                                onClick = {
                                    when {
                                        selected.isNotEmpty() -> selected = if (f in selected) selected - f else selected + f
                                        f.isDirectory -> dir = f
                                        ArchiveEngine.kind(f.name.lowercase()) != null -> dlg = Dlg.ArchiveMenu(f)
                                        else -> openFile(ctx, f)
                                    }
                                },
                                onLongClick = { selected = if (f in selected) selected - f else selected + f }
                            )
                        )
                    }
                }
            }
        }

        // ---- top glass bar ----
        val title = when {
            showSettings -> "Settings"
            selected.isNotEmpty() -> "${selected.size} selected"
            else -> "Storage" + dir.absolutePath.removePrefix(root.absolutePath)
        }
        GlassSurface(
            backdrop,
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = top + 8.dp, start = 12.dp, end = 12.dp)
                .fillMaxWidth()
                .height(60.dp)
        ) {
            Row(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            }
        }

        // ---- bottom glass bar ----
        val acts = buildList<Act> {
            when {
                showSettings -> add(Act("⬅", "Back") { showSettings = false })
                selected.isNotEmpty() -> {
                    add(Act("⎘", "Copy") { clip = selected.toList(); clipCut = false; selected = emptySet() })
                    add(Act("✂", "Cut") { clip = selected.toList(); clipCut = true; selected = emptySet() })
                    add(Act("🗜️", "Compress") { dlg = Dlg.Compress(selected.toList()) })
                    if (selected.size == 1) add(Act("✎", "Rename") { dlg = Dlg.Rename(selected.first()) })
                    add(Act("🗑", "Delete") {
                        val l = selected.toList()
                        if (settings.confirmDelete) dlg = Dlg.Delete(l)
                        else task("Deleting…") { l.forEach { it.deleteRecursively() } }
                    })
                    add(Act("✕", "Cancel") { selected = emptySet() })
                }
                else -> {
                    add(Act("🏠", "Home") { dir = root })
                    add(Act("⬆", "Up") { goUp() })
                    add(Act("＋", "Folder") { dlg = Dlg.NewFolder })
                    if (clip.isNotEmpty()) add(Act("📋", "Paste") {
                        val d = dir; val c = clip; val cut = clipCut
                        task("Pasting…") { pasteInto(d, c, cut) }
                        if (cut) clip = emptyList()
                    })
                    add(Act("⚙", "Settings") { showSettings = true })
                }
            }
        }
        GlassSurface(
            backdrop,
            Modifier
                .align(Alignment.BottomCenter)
                .padding(start = 16.dp, end = 16.dp, bottom = bottom + 12.dp)
                .fillMaxWidth()
                .height(68.dp),
            RoundedCornerShape(34.dp)
        ) {
            Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                acts.forEach { a -> BarButton(a.glyph, a.label, a.onClick) }
            }
        }
    }

    // ---- dialogs ----
    fun extract(f: File, dest: File) = task("Extracting ${f.name}…") { ArchiveEngine.extract(f, dest) }

    when (val d = dlg) {
        null -> {}
        is Dlg.ArchiveMenu -> {
            val base = ArchiveEngine.baseName(d.file)
            AlertDialog(
                onDismissRequest = { dlg = null },
                title = { Text(d.file.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                text = {
                    Column {
                        TextButton(onClick = { dlg = null; extract(d.file, dir) }) { Text("Extract here") }
                        TextButton(onClick = { dlg = null; extract(d.file, File(dir, base)) }) { Text("Extract to “$base”") }
                        TextButton(onClick = {
                            dlg = null
                            task("Reading…") { dlg = Dlg.Contents(d.file, ArchiveEngine.list(d.file)) }
                        }) { Text("View contents") }
                        TextButton(onClick = { dlg = null; openFile(ctx, d.file) }) { Text("Open with…") }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Cancel") } }
            )
        }
        is Dlg.Contents -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("${d.entries.size} items") },
            text = {
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(d.entries) { e ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                            Text(e.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                            if (!e.isDir) Text(formatSize(e.size), fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dlg = null }) { Text("Close") } }
        )
        Dlg.NewFolder -> TextDialog("New folder", "", "Create", { dlg = null }) { name ->
            dlg = null
            val target = File(dir, name)
            task("Creating…") { if (!target.mkdirs()) throw IOException("Can't create folder") }
        }
        is Dlg.Rename -> TextDialog("Rename", d.file.name, "Rename", { dlg = null }) { name ->
            dlg = null
            val f = d.file
            task("Renaming…") { if (!f.renameTo(File(f.parentFile, name))) throw IOException("Rename failed") }
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Delete ${d.files.size} item(s)?") },
            text = { Text("This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    dlg = null
                    task("Deleting…") { d.files.forEach { it.deleteRecursively() } }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Cancel") } }
        )
        is Dlg.Compress -> {
            val defName = if (d.files.size == 1) d.files[0].nameWithoutExtension.ifEmpty { d.files[0].name } else dir.name.ifEmpty { "archive" }
            CompressDialog(defName, settings, { dlg = null }) { name, fmt, level ->
                dlg = null
                val out = uniqueFile(dir, name + "." + ArchiveEngine.extensionFor(fmt))
                val list = d.files
                task("Compressing…") { ArchiveEngine.create(list, out, fmt, level) }
            }
        }
    }

    busy?.let { label ->
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.height(32.dp).width(32.dp))
                    Spacer(Modifier.width(16.dp))
                    Text(label)
                }
            }
        )
    }
}
