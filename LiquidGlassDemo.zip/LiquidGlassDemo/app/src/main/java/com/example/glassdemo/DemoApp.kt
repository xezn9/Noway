package com.example.glassdemo

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.LocalActivity
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.catalog.components.LiquidBottomTab
import com.kyant.backdrop.catalog.components.LiquidBottomTabs
import com.kyant.backdrop.catalog.components.LiquidButton
import com.kyant.backdrop.catalog.components.LiquidDialog
import com.kyant.backdrop.catalog.components.LiquidSlider
import com.kyant.backdrop.catalog.components.LiquidToggle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private class Palette(
    val name: String,
    val light: List<Color>,
    val dark: List<Color>,
    val blobs: List<Color>
)

private val Palettes = listOf(
    Palette(
        "Aurora",
        light = listOf(Color(0xFFF3F7FF), Color(0xFFDDE8FF)),
        dark = listOf(Color(0xFF0B1020), Color(0xFF1B1038)),
        blobs = listOf(
            Color(0xFF0088FF), Color(0xFFFF2D95), Color(0xFF34C759),
            Color(0xFFFFB020), Color(0xFF7C4DFF), Color(0xFF00D4D4)
        )
    ),
    Palette(
        "Sunset",
        light = listOf(Color(0xFFFFF3E8), Color(0xFFFFD9C7)),
        dark = listOf(Color(0xFF2A0F1F), Color(0xFF1A0B14)),
        blobs = listOf(
            Color(0xFFFF6B35), Color(0xFFFF2D55), Color(0xFFFFC400),
            Color(0xFFB517FF), Color(0xFFFF8FA3), Color(0xFFFF3B30)
        )
    ),
    Palette(
        "Ocean",
        light = listOf(Color(0xFFE6FBFF), Color(0xFFC9F0F7)),
        dark = listOf(Color(0xFF04141F), Color(0xFF062A3A)),
        blobs = listOf(
            Color(0xFF00B4D8), Color(0xFF0077B6), Color(0xFF48CAE4),
            Color(0xFF2EC4B6), Color(0xFF3A86FF), Color(0xFF90E0EF)
        )
    ),
)

private class TabSpec(val icon: ImageVector, val label: String)

private val Tabs = listOf(
    TabSpec(Icons.Rounded.TouchApp, "Buttons"),
    TabSpec(Icons.Rounded.Tune, "Controls"),
    TabSpec(Icons.Rounded.ChatBubble, "Dialog"),
    TabSpec(Icons.Rounded.Palette, "Style"),
)

@Composable
fun DemoApp() {
    val systemDark = isSystemInDarkTheme()
    var dark by rememberSaveable { mutableStateOf(systemDark) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var paletteIndex by rememberSaveable { mutableIntStateOf(0) }
    var wifi by rememberSaveable { mutableStateOf(true) }
    var bluetooth by rememberSaveable { mutableStateOf(false) }
    var volume by rememberSaveable { mutableFloatStateOf(0.6f) }
    var brightness by rememberSaveable { mutableFloatStateOf(40f) }
    // dialogKind keeps its value while the dialog fades out, so the text never flips mid-animation
    var dialogVisible by rememberSaveable { mutableStateOf(false) }
    var dialogKind by rememberSaveable { mutableIntStateOf(1) } // 1 = info, 2 = confirm
    val openDialog: (Int) -> Unit = { kind ->
        dialogKind = kind
        dialogVisible = true
    }

    val backdrop = rememberLayerBackdrop()        // wallpaper only (used by the glass components)
    val screenBackdrop = rememberLayerBackdrop()  // the whole screen (used by the dialog)
    val activity = LocalActivity.current as? ComponentActivity

    DisposableEffect(dark) {
        val style = SystemBarStyle.auto(
            android.graphics.Color.TRANSPARENT,
            android.graphics.Color.TRANSPARENT
        ) { dark }
        activity?.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        onDispose { }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        val fg = if (dark) Color.White else Color(0xFF1B1B1F)
        Box(Modifier.fillMaxSize()) {
          Box(Modifier.fillMaxSize().layerBackdrop(screenBackdrop)) {
            // The colorful wallpaper is the layer the glass refracts.
            Wallpaper(
                palette = Palettes[paletteIndex],
                dark = dark,
                modifier = Modifier
                    .fillMaxSize()
                    .layerBackdrop(backdrop)
            )

            Crossfade(targetState = tab, label = "pages") { page ->
                when (page) {
                    0 -> ButtonsPage(backdrop, dark, fg) { openDialog(1) }
                    1 -> ControlsPage(
                        backdrop = backdrop,
                        dark = dark,
                        fg = fg,
                        wifi = wifi,
                        onWifi = { wifi = it },
                        bluetooth = bluetooth,
                        onBluetooth = { bluetooth = it },
                        onDark = { dark = it },
                        volume = volume,
                        onVolume = { volume = it },
                        brightness = brightness,
                        onBrightness = { brightness = it }
                    )
                    2 -> DialogPage(
                        backdrop, dark, fg,
                        onInfo = { openDialog(1) },
                        onConfirm = { openDialog(2) }
                    )
                    else -> StylePage(backdrop, dark, fg, paletteIndex) { paletteIndex = it }
                }
            }

            // Liquid glass bottom tabs
            LiquidBottomTabs(
                selectedTabIndex = { tab },
                onTabSelected = { tab = it },
                backdrop = backdrop,
                tabsCount = Tabs.size,
                darkTheme = dark,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 28.dp, vertical = 14.dp)
            ) {
                Tabs.forEachIndexed { index, spec ->
                    LiquidBottomTab(onClick = { tab = index }) {
                        Icon(
                            spec.icon,
                            contentDescription = null,
                            tint = fg,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            spec.label,
                            color = fg,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }

          } // end of recorded screen

            // Liquid glass dialog (outside the recorded layer, refracts the whole screen)
            LiquidDialog(
                visible = dialogVisible,
                onDismiss = { dialogVisible = false },
                backdrop = screenBackdrop,
                dark = dark,
                title = if (dialogKind == 2) "Delete this item?" else "Liquid Glass",
                message = if (dialogKind == 2)
                    "This action can't be undone. The item will be removed permanently."
                else
                    "A dialog panel that refracts the colorful wallpaper behind it.",
                confirmText = if (dialogKind == 2) "Delete" else "OK",
                dismissText = "Cancel",
                confirmTint = if (dialogKind == 2) Color(0xFFFF3B30) else Color(0xFF0088FF),
                onConfirm = { dialogVisible = false }
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Pages
// ---------------------------------------------------------------------------------------------

@Composable
private fun Page(
    title: String,
    subtitle: String,
    fg: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(Modifier.padding(horizontal = 4.dp, vertical = 4.dp)) {
            Text(title, color = fg, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = fg.copy(alpha = 0.65f), fontSize = 15.sp)
        }
        content()
        Spacer(Modifier.navigationBarsPadding().height(120.dp))
    }
}

@Composable
private fun GlassCard(
    title: String,
    dark: Boolean,
    fg: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                if (dark) Color.White.copy(alpha = 0.08f)
                else Color.White.copy(alpha = 0.50f)
            )
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            title.uppercase(),
            color = fg.copy(alpha = 0.55f),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        content()
    }
}

@Composable
private fun ButtonsPage(
    backdrop: Backdrop,
    dark: Boolean,
    fg: Color,
    onShowDialog: () -> Unit
) {
    Page("Buttons", "LiquidButton — press and drag", fg) {
        GlassCard("Standard", dark, fg) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LiquidButton(onClick = {}, backdrop = backdrop, modifier = Modifier.weight(1f)) {
                    Text("Default", color = fg, fontWeight = FontWeight.Medium)
                }
                LiquidButton(
                    onClick = {},
                    backdrop = backdrop,
                    tint = Color(0xFF0088FF),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Tinted", color = Color.White, fontWeight = FontWeight.Medium)
                }
            }
        }
        GlassCard("Tints", dark, fg) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LiquidButton(
                    onClick = {}, backdrop = backdrop, tint = Color(0xFF34C759),
                    modifier = Modifier.weight(1f)
                ) { Text("Green", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                LiquidButton(
                    onClick = {}, backdrop = backdrop, tint = Color(0xFFFF9500),
                    modifier = Modifier.weight(1f)
                ) { Text("Orange", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                LiquidButton(
                    onClick = {}, backdrop = backdrop, tint = Color(0xFFFF3B30),
                    modifier = Modifier.weight(1f)
                ) { Text("Red", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
        }
        GlassCard("Icons", dark, fg) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                LiquidButton(onClick = {}, backdrop = backdrop) {
                    Icon(Icons.Rounded.Favorite, null, tint = fg, modifier = Modifier.size(24.dp))
                }
                LiquidButton(onClick = {}, backdrop = backdrop) {
                    Icon(Icons.Rounded.Share, null, tint = fg, modifier = Modifier.size(24.dp))
                }
                LiquidButton(onClick = {}, backdrop = backdrop, tint = Color(0xFF7C4DFF)) {
                    Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(24.dp))
                }
            }
        }
        GlassCard("With label", dark, fg) {
            LiquidButton(
                onClick = onShowDialog,
                backdrop = backdrop,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.ChatBubble, null, tint = fg, modifier = Modifier.size(20.dp))
                Text("Open dialog", color = fg, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun ControlsPage(
    backdrop: Backdrop,
    dark: Boolean,
    fg: Color,
    wifi: Boolean,
    onWifi: (Boolean) -> Unit,
    bluetooth: Boolean,
    onBluetooth: (Boolean) -> Unit,
    onDark: (Boolean) -> Unit,
    volume: Float,
    onVolume: (Float) -> Unit,
    brightness: Float,
    onBrightness: (Float) -> Unit
) {
    Page("Controls", "LiquidToggle & LiquidSlider", fg) {
        GlassCard("Toggles", dark, fg) {
            ToggleRow("Wi-Fi", fg, backdrop, dark, wifi, onWifi)
            ToggleRow("Bluetooth", fg, backdrop, dark, bluetooth, onBluetooth)
            ToggleRow("Dark mode", fg, backdrop, dark, dark, onDark)
        }
        GlassCard("Sliders", dark, fg) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Volume", color = fg, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("${(volume * 100).roundToInt()}%", color = fg.copy(alpha = 0.65f), fontSize = 16.sp)
            }
            LiquidSlider(
                value = { volume },
                onValueChange = onVolume,
                valueRange = 0f..1f,
                visibilityThreshold = 0.001f,
                backdrop = backdrop,
                dark = dark,
                modifier = Modifier.padding(vertical = 4.dp)
            )
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Brightness", color = fg, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("${brightness.roundToInt()}", color = fg.copy(alpha = 0.65f), fontSize = 16.sp)
            }
            LiquidSlider(
                value = { brightness },
                onValueChange = onBrightness,
                valueRange = 0f..100f,
                visibilityThreshold = 0.1f,
                backdrop = backdrop,
                dark = dark,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    fg: Color,
    backdrop: Backdrop,
    dark: Boolean,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = fg, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        LiquidToggle(selected = { checked }, onSelect = onChange, backdrop = backdrop, dark = dark)
    }
}

@Composable
private fun DialogPage(
    backdrop: Backdrop,
    dark: Boolean,
    fg: Color,
    onInfo: () -> Unit,
    onConfirm: () -> Unit
) {
    Page("Dialog", "Glass panel with title, message and buttons", fg) {
        GlassCard("Show a dialog", dark, fg) {
            LiquidButton(onClick = onInfo, backdrop = backdrop, modifier = Modifier.fillMaxWidth()) {
                Text("Info dialog", color = fg, fontWeight = FontWeight.Medium)
            }
            LiquidButton(
                onClick = onConfirm,
                backdrop = backdrop,
                tint = Color(0xFFFF3B30),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Confirm dialog", color = Color.White, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun StylePage(
    backdrop: Backdrop,
    dark: Boolean,
    fg: Color,
    selected: Int,
    onSelect: (Int) -> Unit
) {
    Page("Style", "Pick a wallpaper to see how glass refracts it", fg) {
        GlassCard("Wallpaper", dark, fg) {
            Palettes.forEachIndexed { index, palette ->
                LiquidButton(
                    onClick = { onSelect(index) },
                    backdrop = backdrop,
                    tint = if (index == selected) palette.blobs.first() else Color.Unspecified,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        palette.name,
                        color = if (index == selected) Color.White else fg,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Wallpaper: gradient + fixed color blobs + grid lines (sharp edges make refraction visible)
// ---------------------------------------------------------------------------------------------

@Composable
private fun Wallpaper(palette: Palette, dark: Boolean, modifier: Modifier = Modifier) {
    // Static wallpaper: same look as before, frozen (no animation, no per-frame redraw).
    val phase = 0f
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(if (dark) palette.dark else palette.light))

        val count = palette.blobs.size
        palette.blobs.forEachIndexed { i, color ->
            val angle = (phase + i.toFloat() / count) * 2f * PI.toFloat()
            val baseX = w * (0.15f + 0.7f * ((i * 0.37f) % 1f))
            val baseY = h * (0.08f + 0.84f * ((i * 0.23f + 0.1f) % 1f))
            val center = Offset(
                baseX + cos(angle) * w * 0.10f,
                baseY + sin(angle * 1.3f) * h * 0.04f
            )
            val radius = w * (0.22f + 0.05f * (i % 3))
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color.copy(alpha = 0.9f), color.copy(alpha = 0f)),
                    center = center,
                    radius = radius * 1.6f
                ),
                radius = radius * 1.6f,
                center = center
            )
            drawCircle(color = color, radius = radius * 0.5f, center = center)
        }

        val step = 44.dp.toPx()
        val stroke = 1.5f.dp.toPx()
        val line = Color.White.copy(alpha = if (dark) 0.10f else 0.35f)
        var x = 0f
        while (x < w) {
            drawLine(line, Offset(x, 0f), Offset(x, h), strokeWidth = stroke)
            x += step
        }
        var y = 0f
        while (y < h) {
            drawLine(line, Offset(0f, y), Offset(w, y), strokeWidth = stroke)
            y += step
        }
    }
}
