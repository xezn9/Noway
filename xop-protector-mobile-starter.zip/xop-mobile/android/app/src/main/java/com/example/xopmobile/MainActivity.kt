package com.example.xopmobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    companion object {
        // Replace with your own HTTPS server URL before building.
        private const val API_BASE_URL = "https://YOUR-SERVER.example"
        // Prefer a per-user token flow in production; do not hardcode a shared secret in a public app.
        private const val API_TOKEN = "SET_PER_USER_TOKEN"
        private const val PICK_APK = 42
    }

    private lateinit var status: TextView
    private lateinit var selected: TextView
    private lateinit var progress: ProgressBar
    private var chosenUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply { text = "XopProtector Mobile"; textSize = 26f; gravity = Gravity.CENTER }
        val subtitle = TextView(this).apply {
            text = "اختر ملف APK لإرساله إلى محرك الحماية الخاص بك"
            textSize = 16f; gravity = Gravity.CENTER; setPadding(0, 18, 0, 24)
        }
        selected = TextView(this).apply { text = "لم يتم اختيار ملف"; textSize = 14f; setPadding(0, 8, 0, 16) }
        val pick = Button(this).apply { text = "اختيار APK"; setOnClickListener { pickApk() } }
        val protect = Button(this).apply { text = "بدء الحماية"; setOnClickListener { uploadAndProtect() } }
        progress = ProgressBar(this).apply { isIndeterminate = true; visibility = android.view.View.GONE }
        status = TextView(this).apply { text = "جاهز"; textSize = 14f; setPadding(0, 18, 0, 0) }
        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(selected, matchWrap())
        root.addView(pick, matchWrap())
        root.addView(protect, matchWrap())
        root.addView(progress, matchWrap())
        root.addView(status, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 12 }

    private fun pickApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
        }
        startActivityForResult(intent, PICK_APK)
    }

    @Deprecated("Deprecated by platform; retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_APK && resultCode == RESULT_OK) {
            chosenUri = data?.data
            selected.text = chosenUri?.let { displayName(it) } ?: "لم يتم اختيار ملف"
            status.text = "تم اختيار الملف. اضغط بدء الحماية."
        } else if (requestCode == 43 && resultCode == RESULT_OK) {
            val dest = data?.data
            val bytes = pendingOutput
            if (dest != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(dest)?.use { it.write(bytes) }
                    status.text = "تم حفظ APK الناتج بنجاح (${bytes.size / 1024} KB)."
                } catch (e: Exception) { status.text = "تعذر حفظ الملف: ${e.message}" }
            }
            pendingOutput = null
        }
    }

    private fun displayName(uri: Uri): String {
        var name = "APK selected"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return name
    }

    private fun uploadAndProtect() {
        val uri = chosenUri
        if (uri == null) { Toast.makeText(this, "اختَر ملف APK أولاً", Toast.LENGTH_SHORT).show(); return }
        if (API_BASE_URL.contains("YOUR-SERVER") || API_TOKEN == "SET_PER_USER_TOKEN") {
            status.text = "إعداد الخادم مطلوب: عدّل API_BASE_URL وفعّل المصادقة قبل البناء."
            return
        }
        progress.visibility = android.view.View.VISIBLE
        status.text = "جارٍ رفع الملف ومعالجته…"
        thread {
            try {
                val boundary = "XopBoundary${UUID.randomUUID()}"
                val conn = (URL("$API_BASE_URL/v1/protect").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20_000
                    readTimeout = 15 * 60_000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $API_TOKEN")
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                }
                conn.outputStream.use { out ->
                    out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"input.apk\"\r\nContent-Type: application/vnd.android.package-archive\r\n\r\n".toByteArray())
                    contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out) } ?: error("Cannot read selected file")
                    out.write("\r\n--$boundary--\r\n".toByteArray())
                }
                if (conn.responseCode !in 200..299) {
                    val msg = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP ${conn.responseCode}"
                    error(msg.take(400))
                }
                val bytes = BufferedInputStream(conn.inputStream).use { input ->
                    val buffer = ByteArray(64 * 1024)
                    val out = ByteArrayOutputStream()
                    while (true) { val n = input.read(buffer); if (n < 0) break; out.write(buffer, 0, n) }
                    out.toByteArray()
                }
                runOnUiThread {
                    progress.visibility = android.view.View.GONE
                    val outputName = "XopProtected_${System.currentTimeMillis()}.apk"
                    val save = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/vnd.android.package-archive"
                        putExtra(Intent.EXTRA_TITLE, outputName)
                    }
                    pendingOutput = bytes
                    startActivityForResult(save, 43)
                    status.text = "تمت المعالجة؛ اختر مكان حفظ الملف الناتج."
                }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = android.view.View.GONE; status.text = "فشلت العملية: ${e.message ?: "خطأ غير معروف"}" }
            }
        }
    }

    private var pendingOutput: ByteArray? = null

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
    }


}
