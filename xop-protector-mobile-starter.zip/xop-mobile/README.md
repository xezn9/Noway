# XopProtector Mobile Client + Server Engine (starter implementation)

This repository is an Android client plus a private API wrapper for the upstream XopProtector JVM packer. It is a real integration scaffold, but it is **not a ready-to-install APK** and does not include the upstream packer/native shell binaries. Build and test it only with APKs you own or are authorized to modify.

## Architecture
- Android app: selects an APK with Android's system file picker and uploads it to your configured HTTPS API.
- API: authenticates requests, validates upload size/type, runs a fixed XopProtector command in an isolated worker environment, then returns the protected APK.
- Worker image must contain JDK 17, the upstream `protector-packer.jar`, and exported `shell-files` from XopProtector.

Upstream project: https://github.com/xopJack/XopProtector

## Android build
1. Open `android/` in Android Studio (JDK 17, Android SDK installed).
2. In `android/app/src/main/java/com/example/xopmobile/MainActivity.kt`, change `API_BASE_URL` to your HTTPS server URL. Do not use plain HTTP on a public network.
3. Build APK from Android Studio: Build > Build APK(s).

## Server setup
1. Obtain/build XopProtector from its upstream repository and review its license/security docs.
2. Place `protector-packer.jar` at `server/engine/protector-packer.jar` and generated `shell-files/` at `server/engine/shell-files/` (these are intentionally not included here).
3. Set a long random `API_TOKEN` environment variable.
4. Build/run the server using the Dockerfile. Put it behind HTTPS (Caddy/Nginx or managed TLS) and keep the engine isolated from the public internet.

Example:
```bash
export API_TOKEN='replace-with-a-long-random-secret'
docker build -t xop-mobile-server ./server
docker run --rm -p 8000:8000 \
  -e API_TOKEN="$API_TOKEN" \
  -v "$PWD/server/engine:/opt/xop/engine:ro" \
  xop-mobile-server
```

For production, use a queue/worker, per-user rate limits, disk quotas, malware scanning, logs with no APK contents, automatic cleanup, and an authenticated HTTPS endpoint. Do not expose port 8000 directly to the internet. Use a non-root container and strict CPU/memory/time limits.

## API
`POST /v1/protect` with `Authorization: Bearer <API_TOKEN>` and multipart field `file` returns the protected APK as `application/vnd.android.package-archive`. `GET /health` is a health check.

## Current limits
- This starter wraps the upstream CLI; it does not port the packer to Android itself.
- Large APKs may need increased limits and asynchronous jobs.
- APK signing configuration is not embedded; verify the upstream CLI's signing behavior and configure a secure signing key in the isolated worker before production use.
- Test output installation and app startup on a test device before distributing.
