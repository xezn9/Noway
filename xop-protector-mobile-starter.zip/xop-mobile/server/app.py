import hmac
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path
from fastapi import FastAPI, File, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

app = FastAPI(title="XopProtector Mobile API", version="0.1.0")
API_TOKEN = os.environ.get("API_TOKEN", "")
ENGINE = Path(os.environ.get("XOP_ENGINE_DIR", "/opt/xop/engine"))
MAX_BYTES = int(os.environ.get("MAX_APK_BYTES", str(200 * 1024 * 1024)))
TIMEOUT_SECONDS = int(os.environ.get("PROTECT_TIMEOUT_SECONDS", "900"))

@app.get("/health")
def health():
    return {"ok": True, "engine_configured": (ENGINE / "protector-packer.jar").is_file() and (ENGINE / "shell-files").is_dir()}

@app.post("/v1/protect")
def protect(file: UploadFile = File(...), authorization: str | None = Header(default=None)):
    if not API_TOKEN:
        raise HTTPException(503, "Server authentication is not configured")
    expected = f"Bearer {API_TOKEN}"
    if not authorization or not hmac.compare_digest(authorization, expected):
        raise HTTPException(401, "Unauthorized")
    if not file.filename or not file.filename.lower().endswith(".apk"):
        raise HTTPException(400, "Upload a file with .apk extension")

    jar = ENGINE / "protector-packer.jar"
    shell = ENGINE / "shell-files"
    if not jar.is_file() or not shell.is_dir():
        raise HTTPException(503, "XopProtector engine is not installed on this server")

    job_dir = Path(tempfile.mkdtemp(prefix="xop-job-", dir="/tmp/xop-jobs"))
    try:
        input_apk = job_dir / "input.apk"
        output_apk = job_dir / "protected.apk"
        total = 0
        with input_apk.open("wb") as dst:
            while chunk := file.file.read(1024 * 1024):
                total += len(chunk)
                if total > MAX_BYTES:
                    raise HTTPException(413, f"APK exceeds server limit ({MAX_BYTES} bytes)")
                dst.write(chunk)
        if total < 4 or not zipfile.is_zipfile(input_apk):
            raise HTTPException(400, "File is not a valid ZIP-based APK")

        # Fixed argument list: never pass client-supplied command-line options.
        cmd = ["java", "-Xmx2g", "-jar", str(jar), str(input_apk), "-o", str(output_apk), "--shell-dir", str(shell), "--json-progress"]
        try:
            result = subprocess.run(cmd, cwd=str(job_dir), capture_output=True, text=True,
                                    timeout=TIMEOUT_SECONDS, check=False)
        except subprocess.TimeoutExpired:
            raise HTTPException(504, "Protection timed out")
        if result.returncode != 0 or not output_apk.is_file() or output_apk.stat().st_size == 0:
            # Avoid returning full engine logs which could contain sensitive paths.
            detail = (result.stderr or result.stdout or "Packer failed")[-1200:]
            raise HTTPException(422, f"Packer failed: {detail}")
        return FileResponse(output_apk, media_type="application/vnd.android.package-archive",
                            filename="XopProtected.apk", background=BackgroundTask(shutil.rmtree, job_dir, ignore_errors=True))
    finally:
        # FileResponse owns cleanup after successful streaming; clean up on errors.
        if not (job_dir / "protected.apk").is_file():
            shutil.rmtree(job_dir, ignore_errors=True)
