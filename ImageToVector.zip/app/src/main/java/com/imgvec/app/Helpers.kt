package com.imgvec.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import com.imgvec.core.TemplateData
import java.io.File
import kotlin.math.max

/** Decoded picture: ARGB pixels (already EXIF-rotated, max ~1024px) plus a bitmap for the preview. */
class LoadedImage(val pixels: IntArray, val width: Int, val height: Int, val preview: Bitmap)

object ImageLoader {
    private const val MAX_SIDE = 1024

    fun load(ctx: Context, uri: Uri): LoadedImage {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = cr.openInputStream(uri) ?: throw IllegalStateException("تعذر فتح الصورة")
        boundsStream.use { BitmapFactory.decodeStream(it, null, bounds) } // returns null by design (bounds only)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("الملف المختار ليس صورة صالحة")

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("تعذر قراءة الصورة")

        // EXIF rotation (phone photos)
        try {
            val orientation = cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            }
            if (!m.isIdentity) {
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (rotated !== bmp) bmp.recycle()
                bmp = rotated
            }
        } catch (e: Throwable) { /* keep un-rotated */ }

        // scale to at most MAX_SIDE
        val big = max(bmp.width, bmp.height)
        if (big > MAX_SIDE) {
            val f = MAX_SIDE.toFloat() / big
            val scaled = Bitmap.createScaledBitmap(bmp, max(1, (bmp.width * f).toInt()), max(1, (bmp.height * f).toInt()), true)
            if (scaled !== bmp) bmp.recycle()
            bmp = scaled
        }
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        return LoadedImage(px, w, h, bmp)
    }
}

/** Keeps the user's "ready" vector file; falls back to the bundled one. */
class TemplateStore(private val ctx: Context) {
    private val dataFile get() = File(ctx.filesDir, "template.bin")
    private val nameFile get() = File(ctx.filesDir, "template.name")

    val isCustom: Boolean get() = dataFile.exists() && nameFile.exists()

    fun load(): TemplateData {
        if (isCustom) {
            try {
                val t = TemplateData(dataFile.readBytes(), nameFile.readText())
                t.validate()
                return t
            } catch (e: Throwable) { reset() }
        }
        val bytes = ctx.assets.open("template.xml").use { it.readBytes() }
        return TemplateData(bytes, "ic_call_answer.xml").also { it.validate() }
    }

    /** Validates first; only a valid template is ever stored. */
    fun saveCustom(bytes: ByteArray, name: String): TemplateData {
        val t = TemplateData(bytes, name)
        t.validate()
        dataFile.writeBytes(bytes)
        nameFile.writeText(t.name)
        return t
    }

    fun reset() {
        dataFile.delete()
        nameFile.delete()
    }

    companion object {
        fun displayName(ctx: Context, uri: Uri): String {
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrBlank()) return n
                    }
                }
            } catch (e: Throwable) { }
            return uri.lastPathSegment?.substringAfterLast('/') ?: "vector.xml"
        }

        fun readBytes(ctx: Context, uri: Uri, limit: Int = 4 * 1024 * 1024): ByteArray {
            val data = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("تعذر فتح الملف")
            if (data.size > limit) throw IllegalStateException("الملف كبير بشكل غير طبيعي")
            return data
        }
    }
}

/** Writes into the public Downloads folder and reads the file back to prove it is intact. */
object FileSaver {
    fun needsLegacyPermission(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

    fun save(ctx: Context, fileName: String, bytes: ByteArray): String {
        val name = if (fileName.lowercase().endsWith(".xml")) fileName else "$fileName.xml"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveModern(ctx, name, bytes)
        else saveLegacy(name, bytes)
    }

    private fun saveModern(ctx: Context, name: String, bytes: ByteArray): String {
        val resolver = ctx.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI

        // 1) replace our own earlier file with the same name, if there is one
        var uri: Uri? = null
        try {
            resolver.query(
                collection, arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                arrayOf(name, Environment.DIRECTORY_DOWNLOADS + "%"), null
            )?.use { c ->
                if (c.moveToFirst()) uri = ContentUris.withAppendedId(collection, c.getLong(0))
            }
            val existing = uri
            if (existing != null) {
                resolver.openOutputStream(existing, "wt")?.use { it.write(bytes); it.flush() }
                    ?: throw IllegalStateException("cannot open existing")
            }
        } catch (e: Throwable) {
            uri = null // not ours / not writable -> create a fresh file
        }

        // 2) otherwise create a new one
        if (uri == null) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/xml")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val created = resolver.insert(collection, values) ?: throw IllegalStateException("تعذر إنشاء الملف في التنزيلات")
            try {
                resolver.openOutputStream(created, "wt")?.use { it.write(bytes); it.flush() }
                    ?: throw IllegalStateException("تعذر الكتابة في الملف")
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(created, done, null, null)
            } catch (t: Throwable) {
                try { resolver.delete(created, null, null) } catch (e: Throwable) { }
                throw t
            }
            uri = created
        }

        // 3) verify what is on disk
        val back = resolver.openInputStream(uri!!)?.use { it.readBytes() }
        if (back == null || !back.contentEquals(bytes)) throw IllegalStateException("فشل التحقق من الملف بعد الحفظ")
        return "Download/$name"
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(name: String, bytes: ByteArray): String {
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("تعذر الوصول لمجلد التنزيلات")
        val f = File(dir, name)
        f.writeBytes(bytes)
        if (!f.readBytes().contentEquals(bytes)) throw IllegalStateException("فشل التحقق من الملف بعد الحفظ")
        return "Download/$name"
    }
}
