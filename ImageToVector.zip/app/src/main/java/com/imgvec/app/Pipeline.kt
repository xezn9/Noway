package com.imgvec.app

import androidx.core.graphics.PathParser
import com.imgvec.core.Converter
import com.imgvec.core.TemplateData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A finished conversion: the verified output file plus Android Paths for the on-screen preview. */
class Converted(val output: Converter.Output, val paths: List<Pair<Int, android.graphics.Path>>)

object Pipeline {
    /**
     * Converts and then double-checks every path with Android's own PathParser.
     * If anything goes wrong it retries with lower detail instead of failing.
     */
    suspend fun run(
        pixels: IntArray, w: Int, h: Int,
        maxDim: Int, colors: Int, keepTint: Boolean, forceText: Boolean,
        template: TemplateData,
        onProgress: (Float) -> Unit
    ): Converted = withContext(Dispatchers.Default) {
        var dim = maxDim
        var col = colors
        var last: Throwable? = null
        for (attempt in 1..4) {
            try {
                val s = Converter.Settings()
                s.maxDim = dim
                s.colors = col
                s.keepTint = keepTint
                s.forceText = forceText
                val out = Converter.convert(pixels, w, h, s, template) { f -> onProgress(f) }
                val paths = ArrayList<Pair<Int, android.graphics.Path>>(out.model.layers.size)
                for (l in out.model.layers) {
                    val p = try {
                        PathParser.createPathFromPathData(l.pathData)
                    } catch (t: Throwable) {
                        throw IllegalStateException("Android rejected a path: ${t.message}")
                    }
                    paths.add(l.color to p)
                }
                return@withContext Converted(out, paths)
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                throw e                      // bad input (e.g. fully transparent image): retrying will not help
            } catch (t: Throwable) {         // includes OutOfMemoryError
                last = t
                dim = (dim * 0.75f).toInt().coerceAtLeast(48)
                col = (col * 0.8f).toInt().coerceAtLeast(6)
            }
        }
        throw IllegalStateException("فشل التحويل: ${last?.message}")
    }
}
