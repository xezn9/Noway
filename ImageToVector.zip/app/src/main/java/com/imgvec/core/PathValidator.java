package com.imgvec.core;

/** Strict syntax check for Android VectorDrawable pathData strings. */
public final class PathValidator {
    private PathValidator() {}

    private static int params(char c) {
        switch (Character.toLowerCase(c)) {
            case 'm': case 'l': case 't': return 2;
            case 'h': case 'v': return 1;
            case 'c': return 6;
            case 's': case 'q': return 4;
            case 'a': return 7;
            case 'z': return 0;
            default: return -1;
        }
    }

    /** Returns null when valid, otherwise a description of the first problem. */
    public static String validate(String d) {
        if (d == null || d.isEmpty()) return "empty pathData";
        int n = d.length();
        int i = 0;
        boolean first = true;
        while (i < n) {
            char c = d.charAt(i);
            if (c == ' ' || c == ',' || c == '\n' || c == '\r' || c == '\t') { i++; continue; }
            int need = params(c);
            if (need < 0) return "bad command '" + c + "' at " + i;
            if (first && Character.toLowerCase(c) != 'm') return "must start with M";
            first = false;
            i++;
            if (need == 0) continue;
            int count = 0;
            while (true) {
                int j = skipSep(d, i);
                if (j >= n) { i = j; break; }
                char ch = d.charAt(j);
                if (Character.isLetter(ch)) { i = j; break; }
                int e = readNumber(d, j);
                if (e < 0) return "bad number at " + j;
                try {
                    double v = Double.parseDouble(d.substring(j, e));
                    if (Double.isNaN(v) || Double.isInfinite(v)) return "NaN/Inf at " + j;
                } catch (NumberFormatException ex) { return "bad number at " + j; }
                count++;
                i = e;
            }
            if (count == 0 || count % need != 0) return "wrong param count for '" + c + "'";
        }
        return null;
    }

    private static int skipSep(String d, int i) {
        while (i < d.length()) {
            char c = d.charAt(i);
            if (c == ' ' || c == ',' || c == '\n' || c == '\r' || c == '\t') i++; else break;
        }
        return i;
    }

    private static int readNumber(String d, int i) {
        int n = d.length();
        int s = i;
        if (i < n && (d.charAt(i) == '-' || d.charAt(i) == '+')) i++;
        int digits = 0;
        while (i < n && Character.isDigit(d.charAt(i))) { i++; digits++; }
        if (i < n && d.charAt(i) == '.') {
            i++;
            while (i < n && Character.isDigit(d.charAt(i))) { i++; digits++; }
        }
        if (digits == 0) return -1;
        if (i < n && (d.charAt(i) == 'e' || d.charAt(i) == 'E')) {
            int k = i + 1;
            if (k < n && (d.charAt(k) == '-' || d.charAt(k) == '+')) k++;
            int ed = 0;
            while (k < n && Character.isDigit(d.charAt(k))) { k++; ed++; }
            if (ed > 0) i = k;
        }
        return i > s ? i : -1;
    }
}
