package com.imgvec.core;

/** The "ready" vector file supplied by the user (binary AXML extracted from an APK, or plain text XML). */
public final class TemplateData {
    public final byte[] bytes;
    public final boolean binary;
    public final String name;

    public TemplateData(byte[] bytes, String name) {
        if (bytes == null || bytes.length == 0) throw new IllegalArgumentException("empty template");
        this.bytes = bytes;
        this.binary = Axml.isBinary(bytes);
        this.name = (name == null || name.trim().isEmpty()) ? "vector.xml" : name.trim();
    }

    /** Throws IllegalArgumentException when the file cannot serve as a vector template. */
    public void validate() {
        if (binary) {
            Axml.readTemplate(bytes);
        } else {
            VectorXml.readRootAttrs(new String(bytes, java.nio.charset.Charset.forName("UTF-8")));
        }
    }
}
