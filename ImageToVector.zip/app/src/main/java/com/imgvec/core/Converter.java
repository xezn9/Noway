package com.imgvec.core;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/** High-level, crash-proof entry point: image pixels + template -> verified output file. */
public final class Converter {
    private Converter() {}

    public static final class Settings {
        public int maxDim = 256;
        public int colors = 32;
        public boolean keepTint = false;
        public boolean forceText = false;
        public int budgetChars = 250000;
    }

    public static final class Output {
        public final byte[] fileBytes;
        public final String fileName;
        public final String text;
        public final boolean binary;
        public final VectorEngine.Result model;
        public final int attempts;
        public final boolean overBudget;
        Output(byte[] b, String n, String t, boolean bin, VectorEngine.Result m, int a, boolean ob) {
            fileBytes = b; fileName = n; text = t; binary = bin; model = m; attempts = a; overBudget = ob;
        }
    }

    public static Output convert(int[] argb, int w, int h, Settings s, TemplateData tpl, VectorEngine.Progress pr) {
        if (s == null) s = new Settings();
        String lastProblem = "unknown";
        int maxAttempts = 8;
        double scale = 1.0;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            VectorEngine.Options o = new VectorEngine.Options();
            o.maxDim = (int) Math.max(24, Math.round(s.maxDim * scale));
            o.colors = (int) Math.max(4, Math.round(s.colors * (0.5 + 0.5 * scale)));
            VectorEngine.Result r = VectorEngine.convert(argb, w, h, o, attempt == 1 ? pr : null);
            boolean over = r.totalChars > s.budgetChars;
            if (over && attempt < maxAttempts && o.maxDim > 24) { scale *= 0.8; lastProblem = "over budget"; continue; }

            String problem = null;
            for (VectorEngine.Layer l : r.layers) {
                problem = PathValidator.validate(l.pathData);
                if (problem != null) break;
            }
            if (problem != null) { lastProblem = problem; scale *= 0.85; continue; }

            Output out;
            try {
                out = build(r, s, tpl, attempt, over);
            } catch (RuntimeException ex) {
                lastProblem = String.valueOf(ex);
                scale *= 0.85;
                continue;
            }
            return out;
        }
        throw new IllegalStateException("conversion failed: " + lastProblem);
    }

    private static Output build(VectorEngine.Result r, Settings s, TemplateData tpl, int attempt, boolean over) {
        Charset utf8 = Charset.forName("UTF-8");
        String name = tpl != null ? tpl.name : "vector.xml";
        // text variant (used for "copy" and for text templates)
        List<String[]> attrs = null;
        if (tpl != null && !tpl.binary) attrs = VectorXml.readRootAttrs(new String(tpl.bytes, utf8));
        String text = VectorXml.buildText(r, attrs, s.keepTint);
        String tp = VectorXml.verifyText(text, r);
        if (tp != null) throw new IllegalStateException("text verify: " + tp);

        if (tpl != null && tpl.binary && !s.forceText) {
            byte[] bin = buildBinary(r, tpl, s.keepTint);
            String bp = verifyBinary(bin, r);
            if (bp != null) throw new IllegalStateException("binary verify: " + bp);
            return new Output(bin, name, text, true, r, attempt, over);
        }
        return new Output(text.getBytes(utf8), name, text, false, r, attempt, over);
    }

    public static byte[] buildBinary(VectorEngine.Result r, TemplateData tpl, boolean keepTint) {
        Axml.Template t = Axml.readTemplate(tpl.bytes);
        VectorXml.Dim tw = null, th = null;
        List<Axml.Attr> root = new ArrayList<Axml.Attr>();
        for (Axml.Attr a : t.rootAttrs) {
            if (a.resId == 0) continue;
            if (a.resId == Axml.ATTR_WIDTH) {
                if (a.type == Axml.TYPE_DIMENSION) tw = new VectorXml.Dim(Axml.complexToFloat(a.data), a.data & 0xF);
            } else if (a.resId == Axml.ATTR_HEIGHT) {
                if (a.type == Axml.TYPE_DIMENSION) th = new VectorXml.Dim(Axml.complexToFloat(a.data), a.data & 0xF);
            } else if (a.resId == Axml.ATTR_VIEWPORT_W || a.resId == Axml.ATTR_VIEWPORT_H) {
                // replaced below
            } else if (a.resId == Axml.ATTR_TINT && !keepTint) {
                // dropped: a tint would paint the whole picture one colour
            } else {
                root.add(a);
            }
        }
        VectorXml.Dim[] sz = VectorXml.fitSize(tw, th, r.width, r.height);
        root.add(new Axml.Attr(Axml.ATTR_WIDTH, "width", Axml.TYPE_DIMENSION, Axml.createComplexDimension(sz[0].value, sz[0].unit), null));
        root.add(new Axml.Attr(Axml.ATTR_HEIGHT, "height", Axml.TYPE_DIMENSION, Axml.createComplexDimension(sz[1].value, sz[1].unit), null));
        root.add(new Axml.Attr(Axml.ATTR_VIEWPORT_W, "viewportWidth", Axml.TYPE_FLOAT, Float.floatToIntBits((float) r.width), null));
        root.add(new Axml.Attr(Axml.ATTR_VIEWPORT_H, "viewportHeight", Axml.TYPE_FLOAT, Float.floatToIntBits((float) r.height), null));
        List<Axml.PathSpec> paths = new ArrayList<Axml.PathSpec>();
        for (VectorEngine.Layer l : r.layers) paths.add(new Axml.PathSpec(l.color, l.pathData));
        return Axml.build(root, paths, t);
    }

    /** Returns null when the binary XML re-parses and matches the model. */
    public static String verifyBinary(byte[] bin, VectorEngine.Result r) {
        try {
            Axml.Doc d = Axml.parse(bin);
            if (!"vector".equals(d.rootName)) return "root";
            int prev = -1;
            boolean gotW = false, gotH = false, gotVW = false, gotVH = false;
            for (Axml.Attr a : d.rootAttrs) {
                if (a.resId == 0) return "unnamed root attr " + a.name;
                if (a.resId < prev) return "root attrs not sorted";
                prev = a.resId;
                if (a.resId == Axml.ATTR_WIDTH) { gotW = a.type == Axml.TYPE_DIMENSION && Axml.complexToFloat(a.data) > 0; }
                if (a.resId == Axml.ATTR_HEIGHT) { gotH = a.type == Axml.TYPE_DIMENSION && Axml.complexToFloat(a.data) > 0; }
                if (a.resId == Axml.ATTR_VIEWPORT_W) { gotVW = a.type == Axml.TYPE_FLOAT && Float.intBitsToFloat(a.data) == r.width; }
                if (a.resId == Axml.ATTR_VIEWPORT_H) { gotVH = a.type == Axml.TYPE_FLOAT && Float.intBitsToFloat(a.data) == r.height; }
            }
            if (!(gotW && gotH && gotVW && gotVH)) return "size attrs";
            if (d.pathAttrs.size() != r.layers.size()) return "path count";
            for (int i = 0; i < d.pathAttrs.size(); i++) {
                String pd = null; int color = 0; boolean hc = false;
                int pv = -1;
                for (Axml.Attr a : d.pathAttrs.get(i)) {
                    if (a.resId < pv) return "path attrs not sorted";
                    pv = a.resId;
                    if (a.resId == Axml.ATTR_PATHDATA && a.type == Axml.TYPE_STRING) pd = a.str;
                    if (a.resId == Axml.ATTR_FILLCOLOR && a.type == Axml.TYPE_INT_COLOR_ARGB8) { color = a.data; hc = true; }
                }
                if (pd == null || !pd.equals(r.layers.get(i).pathData)) return "pathData " + i;
                if (!hc || color != r.layers.get(i).color) return "color " + i;
                String pv2 = PathValidator.validate(pd);
                if (pv2 != null) return pv2;
            }
            return null;
        } catch (Throwable t) {
            return "parse failed: " + t;
        }
    }
}
