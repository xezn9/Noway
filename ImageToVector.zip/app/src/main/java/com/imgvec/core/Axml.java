package com.imgvec.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Reader / writer for compiled (binary) Android XML restricted to what a VectorDrawable needs:
 * a root &lt;vector&gt; with android: attributes and flat &lt;path&gt; children.
 */
public final class Axml {
    private Axml() {}

    public static final int ATTR_TINT = 0x01010121;
    public static final int ATTR_HEIGHT = 0x01010155;
    public static final int ATTR_WIDTH = 0x01010159;
    public static final int ATTR_AUTOMIRRORED = 0x010103ea;
    public static final int ATTR_VIEWPORT_W = 0x01010402;
    public static final int ATTR_VIEWPORT_H = 0x01010403;
    public static final int ATTR_FILLCOLOR = 0x01010404;
    public static final int ATTR_PATHDATA = 0x01010405;

    public static final int TYPE_REFERENCE = 0x01, TYPE_ATTRIBUTE = 0x02, TYPE_STRING = 0x03,
            TYPE_FLOAT = 0x04, TYPE_DIMENSION = 0x05, TYPE_INT_COLOR_ARGB8 = 0x1c;

    private static final String ANDROID_URI = "http://schemas.android.com/apk/res/android";
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final Charset UTF16 = Charset.forName("UTF-16LE");

    /** One attribute of an element. */
    public static final class Attr {
        public final int resId;
        public final String name;
        public final int type;
        public final int data;
        public final String str;   // only for TYPE_STRING
        public Attr(int resId, String name, int type, int data, String str) {
            this.resId = resId; this.name = name; this.type = type; this.data = data; this.str = str;
        }
    }

    /** Parsed template: root attributes + layout facts needed for byte-faithful regeneration. */
    public static final class Template {
        public final List<Attr> rootAttrs = new ArrayList<Attr>();
        public int lineNs = 1, lineVector = 1, linePathStart = 1, linePathEnd = 1, lineVectorEnd = 1, lineNsEnd = 1;
        public int pathCount;
    }

    public static boolean isBinary(byte[] d) {
        return d != null && d.length > 8 && (d[0] & 255) == 0x03 && d[1] == 0x00 && (d[2] & 255) == 0x08 && d[3] == 0x00;
    }

    // ============================================================================ reading
    private static int u16(byte[] d, int o) { return (d[o] & 255) | ((d[o + 1] & 255) << 8); }
    private static int i32(byte[] d, int o) {
        return (d[o] & 255) | ((d[o + 1] & 255) << 8) | ((d[o + 2] & 255) << 16) | ((d[o + 3] & 255) << 24);
    }

    private static String[] readPool(byte[] d, int o, int size) {
        int count = i32(d, o + 8);
        int flags = i32(d, o + 16);
        int strStart = i32(d, o + 20);
        boolean utf8 = (flags & 0x100) != 0;
        if (count < 0 || count > 1000000) throw new IllegalArgumentException("bad string count");
        String[] out = new String[count];
        for (int i = 0; i < count; i++) {
            int off = i32(d, o + 28 + 4 * i);
            int p = o + strStart + off;
            if (p < o || p >= o + size) throw new IllegalArgumentException("bad string offset");
            if (utf8) {
                int l = d[p++] & 255;
                if ((l & 0x80) != 0) { l = ((l & 0x7f) << 8) | (d[p++] & 255); }
                int bl = d[p++] & 255;
                if ((bl & 0x80) != 0) { bl = ((bl & 0x7f) << 8) | (d[p++] & 255); }
                if (p + bl > d.length) throw new IllegalArgumentException("string out of range");
                out[i] = new String(d, p, bl, UTF8);
            } else {
                int l = u16(d, p); p += 2;
                if ((l & 0x8000) != 0) { l = ((l & 0x7fff) << 16) | u16(d, p); p += 2; }
                if (p + l * 2 > d.length) throw new IllegalArgumentException("string out of range");
                out[i] = new String(d, p, l * 2, UTF16);
            }
        }
        return out;
    }

    /** Fully parsed document (flat vector with paths), used by the template parser and the verifier. */
    public static final class Doc {
        public String[] pool;
        public int[] resMap = new int[0];
        public final List<Attr> rootAttrs = new ArrayList<Attr>();
        public final List<List<Attr>> pathAttrs = new ArrayList<List<Attr>>();
        public String rootName;
        public int lineNs = 1, lineVector = 1, linePathStart = 1, linePathEnd = 1, lineVectorEnd = 1, lineNsEnd = 1;
        public boolean utf8;
    }

    public static Doc parse(byte[] d) {
        if (!isBinary(d)) throw new IllegalArgumentException("not binary XML");
        int total = i32(d, 4);
        if (total != d.length) throw new IllegalArgumentException("size mismatch " + total + " vs " + d.length);
        Doc doc = new Doc();
        int o = 8;
        int depth = 0;
        int androidIdx = -1;
        List<Attr> current = null;
        String curName = null;
        while (o + 8 <= d.length) {
            int type = u16(d, o);
            int hs = u16(d, o + 2);
            int size = i32(d, o + 4);
            if (size < 8 || o + size > d.length || (size & 3) != 0) throw new IllegalArgumentException("bad chunk size");
            switch (type) {
                case 0x0001:
                    doc.pool = readPool(d, o, size);
                    doc.utf8 = (i32(d, o + 16) & 0x100) != 0;
                    break;
                case 0x0180: {
                    int n = (size - 8) / 4;
                    doc.resMap = new int[n];
                    for (int i = 0; i < n; i++) doc.resMap[i] = i32(d, o + 8 + 4 * i);
                    break;
                }
                case 0x0100:
                    doc.lineNs = i32(d, o + 8);
                    break;
                case 0x0101:
                    doc.lineNsEnd = i32(d, o + 8);
                    break;
                case 0x0102: {
                    if (doc.pool == null) throw new IllegalArgumentException("no string pool");
                    int line = i32(d, o + 8);
                    int nameIdx = i32(d, o + 20);
                    int attrStart = u16(d, o + 24);
                    int attrSize = u16(d, o + 26);
                    int attrCount = u16(d, o + 28);
                    if (nameIdx < 0 || nameIdx >= doc.pool.length) throw new IllegalArgumentException("bad name idx");
                    String name = doc.pool[nameIdx];
                    List<Attr> attrs = new ArrayList<Attr>();
                    int ap = o + 16 + attrStart;
                    if (attrSize != 20) throw new IllegalArgumentException("bad attr size");
                    for (int i = 0; i < attrCount; i++) {
                        int q = ap + i * 20;
                        if (q + 20 > o + size) throw new IllegalArgumentException("attr out of range");
                        int ns = i32(d, q);
                        int an = i32(d, q + 4);
                        int raw = i32(d, q + 8);
                        int ty = d[q + 15] & 255;
                        int data = i32(d, q + 16);
                        if (an < 0 || an >= doc.pool.length) throw new IllegalArgumentException("bad attr name");
                        int rid = an < doc.resMap.length ? doc.resMap[an] : 0;
                        String s = null;
                        if (ty == TYPE_STRING) {
                            if (data < 0 || data >= doc.pool.length) throw new IllegalArgumentException("bad string ref");
                            s = doc.pool[data];
                        }
                        if (ns >= 0 && ns < doc.pool.length && ANDROID_URI.equals(doc.pool[ns])) {
                            attrs.add(new Attr(rid, doc.pool[an], ty, data, s));
                        } else if (ns < 0) {
                            attrs.add(new Attr(0, doc.pool[an], ty, data, s));
                        }
                    }
                    depth++;
                    if (depth == 1) {
                        doc.rootName = name;
                        doc.rootAttrs.addAll(attrs);
                        doc.lineVector = line;
                    } else if (depth == 2 && "path".equals(name)) {
                        doc.pathAttrs.add(attrs);
                        doc.linePathStart = line;
                    }
                    curName = name; current = attrs;
                    break;
                }
                case 0x0103: {
                    int line = i32(d, o + 8);
                    if (depth == 2) doc.linePathEnd = line;
                    if (depth == 1) doc.lineVectorEnd = line;
                    depth--;
                    break;
                }
                default:
                    break; // CDATA / unknown chunks are ignored
            }
            o += size;
        }
        if (doc.pool == null) throw new IllegalArgumentException("no string pool");
        if (depth != 0) throw new IllegalArgumentException("unbalanced elements");
        return doc;
    }

    public static Template readTemplate(byte[] d) {
        Doc doc = parse(d);
        if (!"vector".equals(doc.rootName)) throw new IllegalArgumentException("root is not <vector>");
        Template t = new Template();
        t.rootAttrs.addAll(doc.rootAttrs);
        t.lineNs = doc.lineNs; t.lineVector = doc.lineVector; t.linePathStart = doc.linePathStart;
        t.linePathEnd = doc.linePathEnd; t.lineVectorEnd = doc.lineVectorEnd; t.lineNsEnd = doc.lineNsEnd;
        t.pathCount = doc.pathAttrs.size();
        return t;
    }

    // ============================================================================ dimension helpers
    private static final float[] RADIX_MULTS = {
            1.0f / 256f, 1.0f / (1 << 7) / 256f, 1.0f / (1 << 15) / 256f, 1.0f / (1 << 23) / 256f};

    public static float complexToFloat(int data) {
        return (data & 0xFFFFFF00) * RADIX_MULTS[(data >> 4) & 3];
    }

    public static int createComplexDimension(float value, int unit) {
        boolean neg = value < 0;
        if (neg) value = -value;
        long bits = (long) (value * (1 << 23) + 0.5f);
        int radix, shift;
        if ((bits & 0x7fffffL) == 0) { radix = 0; shift = 23; }
        else if ((bits & 0xffffffffff800000L) == 0) { radix = 3; shift = 0; }
        else if ((bits & 0xffffffff80000000L) == 0) { radix = 2; shift = 8; }
        else if ((bits & 0xffffff8000000000L) == 0) { radix = 1; shift = 16; }
        else { radix = 0; shift = 23; }
        int mantissa = (int) ((bits >> shift) & 0xFFFFFF);
        if (neg) mantissa = (-mantissa) & 0xFFFFFF;
        return (radix << 4) | (mantissa << 8) | unit;
    }

    // ============================================================================ writing
    /** One generated &lt;path&gt;. */
    public static final class PathSpec {
        public final int color;
        public final String pathData;
        public PathSpec(int color, String pathData) { this.color = color; this.pathData = pathData; }
    }

    private static final class Pool {
        final List<String> list = new ArrayList<String>();
        int add(String s) { list.add(s); return list.size() - 1; }
        int indexOf(String s) { return list.indexOf(s); }
        int addUnique(String s) { int i = list.indexOf(s); return i >= 0 ? i : add(s); }
    }

    /**
     * Builds a binary vector XML. {@code rootAttrs} must already contain the final root attributes
     * (including viewport/width/height); they are sorted by resource id as the framework requires.
     */
    public static byte[] build(List<Attr> rootAttrs, List<PathSpec> paths, Template lines) {
        List<Attr> root = new ArrayList<Attr>(rootAttrs);
        Collections.sort(root, new Comparator<Attr>() {
            public int compare(Attr a, Attr b) { return a.resId < b.resId ? -1 : (a.resId == b.resId ? 0 : 1); }
        });
        // ---- attribute-name strings in ascending resource id order (they must come first, aligned with resmap)
        List<int[]> ids = new ArrayList<int[]>();
        List<String> names = new ArrayList<String>();
        List<Integer> resIds = new ArrayList<Integer>();
        for (Attr a : root) addRes(resIds, names, a.resId, a.name);
        addRes(resIds, names, ATTR_FILLCOLOR, "fillColor");
        addRes(resIds, names, ATTR_PATHDATA, "pathData");
        // sort (resId, name) pairs by resId
        List<Integer> orderIdx = new ArrayList<Integer>();
        for (int i = 0; i < resIds.size(); i++) orderIdx.add(i);
        final List<Integer> fr = resIds;
        Collections.sort(orderIdx, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                int x = fr.get(a), y = fr.get(b);
                return x < y ? -1 : (x == y ? 0 : 1);
            }
        });
        Pool pool = new Pool();
        int[] resMap = new int[orderIdx.size()];
        for (int i = 0; i < orderIdx.size(); i++) {
            pool.add(names.get(orderIdx.get(i)));
            resMap[i] = resIds.get(orderIdx.get(i));
        }
        // ---- value strings, in order of first use
        int[] rootStrIdx = new int[root.size()];
        for (int i = 0; i < root.size(); i++) {
            Attr a = root.get(i);
            rootStrIdx[i] = a.type == TYPE_STRING ? pool.addUnique(a.str) : -1;
        }
        int[] pathStrIdx = new int[paths.size()];
        for (int i = 0; i < paths.size(); i++) pathStrIdx[i] = pool.addUnique(paths.get(i).pathData);
        int nsPrefix = pool.add("android");
        int nsUri = pool.add(ANDROID_URI);
        int namePath = pool.add("path");
        int nameVector = pool.add("vector");

        boolean useUtf8 = true;
        for (String s : pool.list) if (s.length() > 0x7FFF || s.getBytes(UTF8).length > 0x7FFF) { useUtf8 = false; break; }

        ByteArrayOutputStream body = new ByteArrayOutputStream();
        writePool(body, pool.list, useUtf8);
        // resource map
        chunkHeader(body, 0x0180, 8, 8 + 4 * resMap.length);
        for (int r : resMap) w32(body, r);
        // namespace start
        nsChunk(body, 0x0100, lines.lineNs, nsPrefix, nsUri);
        // vector start
        startElement(body, lines.lineVector, nameVector, nsUri, root, rootStrIdx, pool, resMap, null);
        for (int p = 0; p < paths.size(); p++) {
            List<Attr> pa = new ArrayList<Attr>();
            pa.add(new Attr(ATTR_FILLCOLOR, "fillColor", TYPE_INT_COLOR_ARGB8, paths.get(p).color, null));
            pa.add(new Attr(ATTR_PATHDATA, "pathData", TYPE_STRING, pathStrIdx[p], paths.get(p).pathData));
            int[] si = new int[]{-1, pathStrIdx[p]};
            startElement(body, lines.linePathStart, namePath, nsUri, pa, si, pool, resMap, null);
            endElement(body, lines.linePathEnd, namePath);
        }
        endElement(body, lines.lineVectorEnd, nameVector);
        nsChunk(body, 0x0101, lines.lineNsEnd, nsPrefix, nsUri);

        byte[] b = body.toByteArray();
        ByteArrayOutputStream out = new ByteArrayOutputStream(b.length + 8);
        w16(out, 0x0003); w16(out, 8); w32(out, b.length + 8);
        out.write(b, 0, b.length);
        return out.toByteArray();
    }

    private static void addRes(List<Integer> ids, List<String> names, int id, String name) {
        for (int i = 0; i < ids.size(); i++) if (ids.get(i) == id) return;
        ids.add(id); names.add(name);
    }

    private static void startElement(ByteArrayOutputStream o, int line, int nameIdx, int nsUri,
                                     List<Attr> attrs, int[] strIdx, Pool pool, int[] resMap, Object unused) {
        int size = 16 + 20 + 20 * attrs.size();
        chunkHeader(o, 0x0102, 16, size);
        w32(o, line); w32(o, -1);        // header: line, comment
        w32(o, -1); w32(o, nameIdx);     // ns, name
        w16(o, 20); w16(o, 20); w16(o, attrs.size());
        w16(o, 0); w16(o, 0); w16(o, 0); // id/class/style index
        for (int i = 0; i < attrs.size(); i++) {
            Attr a = attrs.get(i);
            int nameStringIdx = -1;
            for (int k = 0; k < resMap.length; k++) if (resMap[k] == a.resId) { nameStringIdx = k; break; }
            if (nameStringIdx < 0) throw new IllegalStateException("attr without res id: " + a.name);
            w32(o, nsUri);
            w32(o, nameStringIdx);
            int data = a.data;
            int raw = -1;
            if (a.type == TYPE_STRING) { data = strIdx[i]; raw = data; }
            w32(o, raw);
            w16(o, 8); o.write(0); o.write(a.type);
            w32(o, data);
        }
    }

    private static void endElement(ByteArrayOutputStream o, int line, int nameIdx) {
        chunkHeader(o, 0x0103, 16, 24);
        w32(o, line); w32(o, -1); w32(o, -1); w32(o, nameIdx);
    }

    private static void nsChunk(ByteArrayOutputStream o, int type, int line, int prefix, int uri) {
        chunkHeader(o, type, 16, 24);
        w32(o, line); w32(o, -1); w32(o, prefix); w32(o, uri);
    }

    private static void writePool(ByteArrayOutputStream o, List<String> strings, boolean utf8) {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offs = new int[strings.size()];
        for (int i = 0; i < strings.size(); i++) {
            offs[i] = data.size();
            String s = strings.get(i);
            if (utf8) {
                byte[] b = s.getBytes(UTF8);
                encLen8(data, s.length());
                encLen8(data, b.length);
                data.write(b, 0, b.length);
                data.write(0);
            } else {
                int l = s.length();
                if (l > 0x7FFF) { w16(data, 0x8000 | (l >>> 16)); w16(data, l & 0xFFFF); }
                else w16(data, l);
                byte[] b = s.getBytes(UTF16);
                data.write(b, 0, b.length);
                w16(data, 0);
            }
        }
        while ((data.size() & 3) != 0) data.write(0);
        int headerSize = 28;
        int strStart = headerSize + 4 * strings.size();
        int size = strStart + data.size();
        chunkHeader(o, 0x0001, headerSize, size);
        w32(o, strings.size());
        w32(o, 0);
        w32(o, utf8 ? 0x100 : 0);
        w32(o, strStart);
        w32(o, 0);
        for (int off : offs) w32(o, off);
        byte[] db = data.toByteArray();
        o.write(db, 0, db.length);
    }

    private static void encLen8(ByteArrayOutputStream o, int l) {
        if (l > 0x7F) { o.write(0x80 | (l >> 8)); o.write(l & 0xFF); }
        else o.write(l);
    }

    private static void chunkHeader(ByteArrayOutputStream o, int type, int hs, int size) {
        w16(o, type); w16(o, hs); w32(o, size);
    }

    private static void w16(ByteArrayOutputStream o, int v) { o.write(v & 255); o.write((v >> 8) & 255); }
    private static void w32(ByteArrayOutputStream o, int v) {
        o.write(v & 255); o.write((v >> 8) & 255); o.write((v >> 16) & 255); o.write((v >>> 24) & 255);
    }
}
