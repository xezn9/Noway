# Image to Vector (Liquid Glass)

تطبيق أندرويد: تختار صورة ← يطلع Drawable vector XML ← زر نسخ + زر تنزيل XML.

## كيف يشتغل ملف القالب
- القالب الافتراضي هو `ic_call_answer.xml` اللي رفعته (ثنائي مستخرج من APK).
- من التطبيق اضغط «اختيار قالب» وانتخب أي ملف vector جاهز (ثنائي أو نصي).
- الكود الجديد يستبدل محتوى القالب ويحفظه بنفس اسم الملف في مجلد Download.
  إذا نزّلت مرة ثانية بنفس الاسم يستبدل الملف القديم.
- الـ tint ينحذف افتراضياً (حتى ما تتلوّن الصورة بلون واحد). تكدر تفعّله من الإعدادات.

## البناء
1. Android Studio: افتح المجلد → Sync → Run.
2. بدون كمبيوتر: ارفع المجلد على GitHub، يشتغل `.github/workflows/build.yml` ويطلع APK في Actions → Artifacts.

## التحقق
`tools/CoreSelfTest.java` يختبر المحرك (بدون أندرويد):
java -m jdk.compiler/com.sun.tools.javac.Main -d out app/src/main/java/com/imgvec/core/*.java tools/CoreSelfTest.java
java -cp out CoreSelfTest app/src/main/assets/template.xml صورة.png out_dir
