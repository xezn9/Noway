import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../core/glass.dart';
import '../core/settings.dart';
import '../engine/analysis.dart';
import '../engine/cloud.dart';
import '../engine/enhancer.dart';
import 'result_screen.dart';

enum EngineMode { local, cloud }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ImagePicker _picker = ImagePicker();

  Uint8List? _bytes;
  ImageAnalysis? _analysis;
  bool _analyzing = false;
  bool _working = false;
  String _stage = '';
  Timer? _stageTimer;

  EngineMode _mode = EngineMode.local;
  int _scale = 2;
  double _strength = 0.7;

  @override
  void dispose() {
    _stageTimer?.cancel();
    super.dispose();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(msg),
          behavior: SnackBarBehavior.floating,
          backgroundColor: const Color(0xFF1B2347),
        ),
      );
  }

  Future<void> _pick(ImageSource source) async {
    try {
      final file = await _picker.pickImage(source: source);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      setState(() {
        _bytes = bytes;
        _analysis = null;
        _analyzing = true;
      });
      try {
        final a = await compute(analyzeBytes, bytes);
        if (!mounted) return;
        setState(() {
          _analysis = a;
          _analyzing = false;
        });
      } catch (e) {
        if (!mounted) return;
        setState(() {
          _bytes = null;
          _analyzing = false;
        });
        _toast('تعذر قراءة هذه الصورة. جرّب صورة JPG أو PNG.');
      }
    } catch (e) {
      _toast('تعذر فتح الصورة.');
    }
  }

  void _startStages(List<String> stages) {
    var i = 0;
    _stage = stages.first;
    _stageTimer?.cancel();
    _stageTimer = Timer.periodic(const Duration(milliseconds: 1800), (_) {
      if (!mounted) return;
      i = (i + 1) % stages.length;
      setState(() => _stage = stages[i]);
    });
  }

  Future<void> _enhance() async {
    final bytes = _bytes;
    if (bytes == null || _working) return;

    if (_mode == EngineMode.cloud) {
      final token = await AppSettings.getToken();
      if (token.isEmpty) {
        _toast('أدخل مفتاح Replicate في الإعدادات أولاً.');
        _openSettings();
        return;
      }
    }

    setState(() => _working = true);
    try {
      if (_mode == EngineMode.local) {
        _startStages(const [
          'تحليل الصورة...',
          'تكبير الدقة...',
          'إزالة الضوضاء...',
          'استعادة التفاصيل...',
          'ضبط الألوان والإضاءة...',
        ]);
        final res = await compute(
          enhanceBytes,
          EnhanceRequest(bytes: bytes, scale: _scale, strength: _strength),
        );
        if (!mounted) return;
        final info =
            'المحرك: محلي • ${res.analysis.kindLabel}\n'
            'الدقة: ${res.analysis.width}×${res.analysis.height} ← ${res.width}×${res.height}'
            '${res.appliedScale < _scale ? ' (خُفّض التكبير لحماية الذاكرة)' : ''}';
        await _openResult(bytes, res.bytes, info);
      } else {
        final token = await AppSettings.getToken();
        _startStages(const ['تجهيز الصورة...']);
        final prep = await compute(prepareForCloud, bytes);
        if (!mounted) return;
        _stageTimer?.cancel();
        final cloudScale = prep.width > 900 || prep.height > 900 ? 2 : 4;
        final out = await CloudEnhancer(token).enhance(
          prep.bytes,
          scale: cloudScale,
          faceEnhance: prep.kind == ImageKind.person,
          onStatus: (s) {
            if (mounted) setState(() => _stage = s);
          },
        );
        if (!mounted) return;
        final info =
            'المحرك: ذكاء اصطناعي سحابي (Real-ESRGAN)\n'
            'تكبير ×$cloudScale${prep.kind == ImageKind.person ? ' • مع تحسين الوجوه' : ''}';
        await _openResult(bytes, out, info);
      }
    } on CloudException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('حدث خطأ أثناء المعالجة. جرّب صورة أصغر أو تكبيراً أقل.');
    } finally {
      _stageTimer?.cancel();
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _openResult(Uint8List before, Uint8List after, String info) async {
    final r = await Navigator.of(context).push<bool>(
      SlidePageRoute<bool>(
        page: ResultScreen(before: before, after: after, info: info),
      ),
    );
    if (r == true && mounted) {
      setState(() {
        _bytes = null;
        _analysis = null;
      });
    }
  }

  Future<void> _openSettings() async {
    final current = await AppSettings.getToken();
    if (!mounted) return;
    final controller = TextEditingController(text: current);
    await showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'إغلاق',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 420),
      pageBuilder: (context, a, b) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Material(
                color: Colors.transparent,
                child: GlassCard(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'الذكاء الاصطناعي السحابي',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'للحصول على أقوى جودة، ضع مفتاح API من موقع replicate.com '
                        '(الحساب ← API tokens). المفتاح يبقى على جهازك فقط. '
                        'الخدمة قد تكون مدفوعة حسب رصيدك عند Replicate.',
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.8),
                            height: 1.5,
                            fontSize: 13),
                      ),
                      const SizedBox(height: 14),
                      TextField(
                        controller: controller,
                        obscureText: true,
                        style: const TextStyle(color: Colors.white),
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                          hintText: 'r8_xxxxxxxxxxxxxxxx',
                          hintStyle: TextStyle(
                              color: Colors.white.withValues(alpha: 0.4)),
                          filled: true,
                          fillColor: Colors.white.withValues(alpha: 0.1),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      GlassButton(
                        label: 'حفظ',
                        icon: Icons.check_rounded,
                        primary: true,
                        onPressed: () async {
                          await AppSettings.setToken(controller.text);
                          if (context.mounted) Navigator.of(context).pop();
                          _toast('تم حفظ المفتاح');
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (context, anim, secondary, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
        return SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.4),
            end: Offset.zero,
          ).animate(curved),
          child: FadeTransition(opacity: curved, child: child),
        );
      },
    );
    controller.dispose();
  }

  Widget _chip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withValues(alpha: 0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: AppColors.accent3),
          const SizedBox(width: 6),
          Text(text,
              style: const TextStyle(color: Colors.white, fontSize: 12.5)),
        ],
      ),
    );
  }

  Widget _preview() {
    final bytes = _bytes;
    return GlassCard(
      padding: const EdgeInsets.all(8),
      radius: 30,
      child: AspectRatio(
        aspectRatio: 1.15,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            switchInCurve: Curves.easeOutCubic,
            transitionBuilder: (child, anim) => SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.3, 0),
                end: Offset.zero,
              ).animate(anim),
              child: FadeTransition(opacity: anim, child: child),
            ),
            child: bytes == null
                ? Center(
                    key: const ValueKey('empty'),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.auto_awesome_rounded,
                            size: 56,
                            color: Colors.white.withValues(alpha: 0.85)),
                        const SizedBox(height: 12),
                        Text(
                          'اختر صورة لتحسينها',
                          style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.9),
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  )
                : SizedBox.expand(
                    key: ValueKey(bytes.length),
                    child: Image.memory(
                      bytes,
                      fit: BoxFit.cover,
                      cacheWidth: 1200,
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  Widget _analysisCard() {
    final a = _analysis;
    if (_analyzing) {
      return const SlideIn(
        child: GlassCard(
          padding: EdgeInsets.all(16),
          radius: 22,
          child: Row(
            children: [
              SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    strokeWidth: 2.4, color: Colors.white),
              ),
              SizedBox(width: 12),
              Text('جاري تحليل الصورة...',
                  style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
      );
    }
    if (a == null) return const SizedBox.shrink();
    return SlideIn(
      from: const Offset(0.3, 0),
      child: GlassCard(
        padding: const EdgeInsets.all(14),
        radius: 22,
        child: Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _chip(
              a.kind == ImageKind.person
                  ? Icons.face_retouching_natural_rounded
                  : (a.kind == ImageKind.graphic
                      ? Icons.text_fields_rounded
                      : Icons.landscape_rounded),
              a.kindLabel,
            ),
            _chip(Icons.blur_on_rounded, a.sharpLabel),
            _chip(Icons.grain_rounded, a.noiseLabel),
            _chip(Icons.wb_sunny_rounded, a.lightLabel),
            _chip(Icons.aspect_ratio_rounded, '${a.width}×${a.height}'),
          ],
        ),
      ),
    );
  }

  Widget _controls() {
    return SlideIn(
      from: const Offset(0, 0.3),
      child: GlassCard(
        padding: const EdgeInsets.all(16),
        radius: 26,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('المحرك',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            GlassSegmented<EngineMode>(
              options: const {
                EngineMode.local: 'محلي (بدون إنترنت)',
                EngineMode.cloud: 'ذكاء سحابي AI',
              },
              value: _mode,
              onChanged: (v) => setState(() => _mode = v),
            ),
            if (_mode == EngineMode.local) ...[
              const SizedBox(height: 16),
              const Text('التكبير',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              GlassSegmented<int>(
                options: const {1: '×1', 2: '×2', 3: '×3', 4: '×4'},
                value: _scale,
                onChanged: (v) => setState(() => _scale = v),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Text('قوة التحسين',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Text('${(_strength * 100).round()}%',
                      style: const TextStyle(color: Colors.white70)),
                ],
              ),
              Slider(
                value: _strength,
                min: 0.1,
                max: 1.0,
                activeColor: AppColors.accent,
                inactiveColor: Colors.white24,
                onChanged: (v) => setState(() => _strength = v),
              ),
            ] else ...[
              const SizedBox(height: 12),
              Text(
                'يرسل الصورة إلى موديل Real-ESRGAN للحصول على أعلى جودة '
                'وتفاصيل واقعية. يحتاج إنترنت ومفتاح Replicate من الإعدادات.',
                style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.75),
                    height: 1.5,
                    fontSize: 12.5),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasImage = _bytes != null;
    return Scaffold(
      body: GlassBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
            children: [
              SlideIn(
                from: const Offset(0, -0.5),
                child: Row(
                  children: [
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Lumina',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 30,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1)),
                          SizedBox(height: 2),
                          Text('محسّن الصور الذكي',
                              style: TextStyle(
                                  color: Colors.white70, fontSize: 14)),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 56,
                      child: GlassButton(
                        label: '',
                        icon: Icons.settings_rounded,
                        onPressed: _openSettings,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              SlideIn(
                delay: const Duration(milliseconds: 120),
                child: _preview(),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: GlassButton(
                      label: 'المعرض',
                      icon: Icons.photo_library_rounded,
                      delay: const Duration(milliseconds: 220),
                      onPressed: _working
                          ? null
                          : () => _pick(ImageSource.gallery),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GlassButton(
                      label: 'الكاميرا',
                      icon: Icons.photo_camera_rounded,
                      delay: const Duration(milliseconds: 320),
                      onPressed: _working
                          ? null
                          : () => _pick(ImageSource.camera),
                    ),
                  ),
                ],
              ),
              if (hasImage) ...[
                const SizedBox(height: 14),
                _analysisCard(),
                const SizedBox(height: 14),
                _controls(),
                const SizedBox(height: 16),
                GlassButton(
                  label: _working
                      ? (_stage.isEmpty ? 'جاري التحسين...' : _stage)
                      : 'حسّن الصورة الآن',
                  icon: Icons.auto_fix_high_rounded,
                  primary: true,
                  loading: _working,
                  delay: const Duration(milliseconds: 100),
                  onPressed: (_analyzing || _working) ? null : _enhance,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
