import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:gal/gal.dart';

import '../core/glass.dart';

class ResultScreen extends StatefulWidget {
  const ResultScreen({
    super.key,
    required this.before,
    required this.after,
    required this.info,
  });

  final Uint8List before;
  final Uint8List after;
  final String info;

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  double _pos = 0.5;
  bool _saving = false;
  bool _saved = false;

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await Gal.putImageBytes(widget.after, album: 'Lumina');
      if (!mounted) return;
      setState(() => _saved = true);
      _toast('تم الحفظ في المعرض ✓');
    } catch (e) {
      if (!mounted) return;
      _toast('تعذر الحفظ. تأكد من صلاحية الوصول للصور.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1B2347),
      ),
    );
  }

  Widget _tag(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.45),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        text,
        style: const TextStyle(
            color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12),
      ),
    );
  }

  Widget _compare() {
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        final h = c.maxHeight;
        final x = w * _pos;
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onHorizontalDragUpdate: (d) {
            setState(() {
              _pos = ((_pos * w) + d.delta.dx) / w;
              if (_pos < 0.0) _pos = 0.0;
              if (_pos > 1.0) _pos = 1.0;
            });
          },
          onTapDown: (d) {
            setState(() => _pos = (d.localPosition.dx / w).clamp(0.0, 1.0));
          },
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.memory(
                  widget.after,
                  fit: BoxFit.contain,
                  cacheWidth: 2048,
                  gaplessPlayback: true,
                ),
              ),
              Positioned.fill(
                child: ClipRect(
                  clipper: _LeftClipper(x),
                  child: Image.memory(
                    widget.before,
                    fit: BoxFit.contain,
                    cacheWidth: 2048,
                    gaplessPlayback: true,
                  ),
                ),
              ),
              Positioned(
                left: x - 1.5,
                top: 0,
                bottom: 0,
                child: Container(width: 3, color: Colors.white),
              ),
              Positioned(
                left: x - 22,
                top: h / 2 - 22,
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withValues(alpha: 0.9),
                    boxShadow: const [
                      BoxShadow(color: Colors.black38, blurRadius: 10),
                    ],
                  ),
                  child: const Icon(Icons.swap_horiz_rounded,
                      color: Color(0xFF1B2347)),
                ),
              ),
              Positioned(left: 10, top: 10, child: _tag('قبل')),
              Positioned(right: 10, top: 10, child: _tag('بعد')),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GlassBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: Column(
              children: [
                SlideIn(
                  from: const Offset(0, -0.6),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 120,
                        child: GlassButton(
                          label: 'رجوع',
                          icon: Icons.arrow_back_rounded,
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                      ),
                      const Spacer(),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: SlideIn(
                    delay: const Duration(milliseconds: 150),
                    child: GlassCard(
                      padding: const EdgeInsets.all(8),
                      radius: 30,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(22),
                        child: _compare(),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SlideIn(
                  delay: const Duration(milliseconds: 300),
                  child: GlassCard(
                    padding: const EdgeInsets.all(12),
                    radius: 22,
                    child: Row(
                      children: [
                        const Icon(Icons.auto_awesome_rounded,
                            color: AppColors.accent3, size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            widget.info,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 13, height: 1.4),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                GlassButton(
                  label: _saved ? 'تم الحفظ' : 'حفظ في المعرض',
                  icon: _saved ? Icons.check_rounded : Icons.download_rounded,
                  primary: true,
                  loading: _saving,
                  delay: const Duration(milliseconds: 420),
                  onPressed: _save,
                ),
                const SizedBox(height: 10),
                GlassButton(
                  label: 'صورة جديدة',
                  icon: Icons.add_photo_alternate_rounded,
                  delay: const Duration(milliseconds: 520),
                  onPressed: () => Navigator.of(context).pop(true),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LeftClipper extends CustomClipper<Rect> {
  _LeftClipper(this.x);

  final double x;

  @override
  Rect getClip(Size size) => Rect.fromLTWH(0, 0, x, size.height);

  @override
  bool shouldReclip(covariant _LeftClipper oldClipper) => oldClipper.x != x;
}
