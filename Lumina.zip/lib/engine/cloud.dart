import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

class CloudException implements Exception {
  CloudException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// وضع الذكاء الاصطناعي السحابي: Real-ESRGAN عبر Replicate.
/// المستخدم يضع مفتاح API الخاص به في الإعدادات.
class CloudEnhancer {
  CloudEnhancer(this.token);

  final String token;

  static const String _base = 'https://api.replicate.com/v1';
  static const String _model = 'nightmareai/real-esrgan';

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      };

  void _check(http.Response res) {
    if (res.statusCode >= 200 && res.statusCode < 300) return;
    if (res.statusCode == 401) {
      throw CloudException('مفتاح Replicate غير صحيح. راجع الإعدادات.');
    }
    if (res.statusCode == 402) {
      throw CloudException('رصيد Replicate غير كافٍ. أضف رصيداً ثم أعد المحاولة.');
    }
    if (res.statusCode == 429) {
      throw CloudException('طلبات كثيرة، انتظر قليلاً ثم أعد المحاولة.');
    }
    throw CloudException('خطأ من الخادم (${res.statusCode}).');
  }

  Future<Uint8List> enhance(
    Uint8List jpg, {
    required int scale,
    required bool faceEnhance,
    void Function(String status)? onStatus,
  }) async {
    try {
      onStatus?.call('الاتصال بالخادم...');
      final modelRes = await http
          .get(Uri.parse('$_base/models/$_model'), headers: _headers)
          .timeout(const Duration(seconds: 30));
      _check(modelRes);
      final modelJson = jsonDecode(modelRes.body) as Map<String, dynamic>;
      final latest = modelJson['latest_version'] as Map<String, dynamic>?;
      final version = latest?['id'] as String?;
      if (version == null) {
        throw CloudException('تعذر الحصول على نسخة الموديل.');
      }

      onStatus?.call('رفع الصورة...');
      final dataUri = 'data:image/jpeg;base64,${base64Encode(jpg)}';
      final createRes = await http
          .post(
            Uri.parse('$_base/predictions'),
            headers: {..._headers, 'Prefer': 'wait=50'},
            body: jsonEncode({
              'version': version,
              'input': {
                'image': dataUri,
                'scale': scale,
                'face_enhance': faceEnhance,
              },
            }),
          )
          .timeout(const Duration(seconds: 90));
      _check(createRes);

      var prediction = jsonDecode(createRes.body) as Map<String, dynamic>;
      final getUrl = (prediction['urls'] as Map<String, dynamic>?)?['get'] as String?;

      onStatus?.call('الذكاء الاصطناعي يعالج الصورة...');
      final deadline = DateTime.now().add(const Duration(minutes: 4));
      while (true) {
        final status = prediction['status'] as String?;
        if (status == 'succeeded') break;
        if (status == 'failed' || status == 'canceled') {
          final err = prediction['error'];
          throw CloudException('فشلت المعالجة السحابية${err != null ? ': $err' : ''}');
        }
        if (getUrl == null || DateTime.now().isAfter(deadline)) {
          throw CloudException('انتهت مهلة المعالجة السحابية.');
        }
        await Future<void>.delayed(const Duration(seconds: 2));
        final poll = await http
            .get(Uri.parse(getUrl), headers: _headers)
            .timeout(const Duration(seconds: 30));
        _check(poll);
        prediction = jsonDecode(poll.body) as Map<String, dynamic>;
      }

      final output = prediction['output'];
      String? url;
      if (output is String) {
        url = output;
      } else if (output is List && output.isNotEmpty) {
        url = output.first.toString();
      }
      if (url == null) throw CloudException('لم يرجع الخادم صورة.');

      onStatus?.call('تنزيل النتيجة...');
      final img = await http
          .get(Uri.parse(url))
          .timeout(const Duration(minutes: 2));
      if (img.statusCode != 200) {
        throw CloudException('تعذر تنزيل الصورة الناتجة.');
      }
      return img.bodyBytes;
    } on CloudException {
      rethrow;
    } on TimeoutException {
      throw CloudException('انتهت مهلة الاتصال. تأكد من الإنترنت.');
    } catch (e) {
      throw CloudException('تعذر الاتصال بالخادم السحابي. تأكد من الإنترنت.');
    }
  }
}
