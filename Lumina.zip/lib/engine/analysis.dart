import 'dart:math' as math;
import 'dart:typed_data';

import 'package:image/image.dart' as img;

/// نوع المحتوى المتوقع.
enum ImageKind { person, graphic, scene }

/// نتيجة تحليل الصورة (كلها أرقام ونصوص بسيطة حتى تنتقل بين الـ isolates).
class ImageAnalysis {
  const ImageAnalysis({
    required this.kind,
    required this.width,
    required this.height,
    required this.sharpness,
    required this.noise,
    required this.brightness,
    required this.contrast,
    required this.skinRatio,
  });

  final ImageKind kind;
  final int width;
  final int height;

  /// تباين لابلاس: أقل = أكثر ضبابية.
  final double sharpness;

  /// تقدير الضوضاء (سيغما).
  final double noise;

  /// متوسط الإضاءة 0..255
  final double brightness;

  /// الانحراف المعياري للإضاءة.
  final double contrast;

  /// نسبة ألوان البشرة.
  final double skinRatio;

  String get kindLabel {
    switch (kind) {
      case ImageKind.person:
        return 'صورة شخص';
      case ImageKind.graphic:
        return 'رسوم / نص';
      case ImageKind.scene:
        return 'مشهد / أشياء';
    }
  }

  String get sharpLabel {
    if (sharpness < 40) return 'ضبابية';
    if (sharpness < 180) return 'متوسطة الحدة';
    return 'حادة';
  }

  String get noiseLabel {
    if (noise < 1.5) return 'نظيفة';
    if (noise < 4) return 'ضوضاء خفيفة';
    return 'ضوضاء عالية';
  }

  String get lightLabel {
    if (brightness < 80) return 'مظلمة';
    if (brightness > 175) return 'ساطعة';
    return 'إضاءة جيدة';
  }
}

int _ci(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

/// يحلل صورة مفكوكة. يُستدعى من داخل isolate.
ImageAnalysis analyzeImage(img.Image oriented) {
  final origW = oriented.width;
  final origH = oriented.height;

  // ---- 1) الحدة والضوضاء من قص مركزي بدقة الصورة الأصلية ----
  final cw = math.min(256, origW);
  final ch = math.min(256, origH);
  final x0 = (origW - cw) ~/ 2;
  final y0 = (origH - ch) ~/ 2;
  final crop = Uint8List(cw * ch);
  for (var y = 0; y < ch; y++) {
    for (var x = 0; x < cw; x++) {
      final p = oriented.getPixel(x0 + x, y0 + y);
      crop[y * cw + x] =
          _ci(((299 * p.r.toInt() + 587 * p.g.toInt() + 114 * p.b.toInt()) ~/ 1000), 0, 255);
    }
  }

  var lapSum = 0.0;
  var lapSq = 0.0;
  var lapN = 0;
  var noiseSum = 0.0;
  var noiseN = 0;
  for (var y = 1; y < ch - 1; y++) {
    for (var x = 1; x < cw - 1; x++) {
      final i = y * cw + x;
      final c = crop[i];
      final lap = 4 * c - crop[i - 1] - crop[i + 1] - crop[i - cw] - crop[i + cw];
      lapSum += lap;
      lapSq += lap * lap;
      lapN++;
      // Immerkaer noise estimator
      final n = crop[i - cw - 1] -
          2 * crop[i - cw] +
          crop[i - cw + 1] -
          2 * crop[i - 1] +
          4 * c -
          2 * crop[i + 1] +
          crop[i + cw - 1] -
          2 * crop[i + cw] +
          crop[i + cw + 1];
      noiseSum += n.abs();
      noiseN++;
    }
  }
  var sharpness = 0.0;
  var noise = 0.0;
  if (lapN > 0) {
    final mean = lapSum / lapN;
    sharpness = lapSq / lapN - mean * mean;
    noise = math.sqrt(math.pi / 2) * noiseSum / (6 * noiseN);
  }

  // ---- 2) باقي المقاييس من نسخة مصغرة ----
  const limit = 360;
  img.Image small = oriented;
  if (origW >= origH && origW > limit) {
    small = img.copyResize(oriented,
        width: limit, interpolation: img.Interpolation.average);
  } else if (origH > origW && origH > limit) {
    small = img.copyResize(oriented,
        height: limit, interpolation: img.Interpolation.average);
  }
  final w = small.width;
  final h = small.height;
  final total = w * h;
  final gray = Uint8List(total);
  var skin = 0;
  var sum = 0.0;
  var sumSq = 0.0;
  final bins = <int, int>{};

  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final p = small.getPixel(x, y);
      final r = p.r.toInt();
      final g = p.g.toInt();
      final b = p.b.toInt();
      final yy = (299 * r + 587 * g + 114 * b) ~/ 1000;
      gray[y * w + x] = _ci(yy, 0, 255);
      sum += yy;
      sumSq += yy * yy;

      final cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      final cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
      if (cb >= 77 && cb <= 127 && cr >= 133 && cr <= 173 &&
          r > 95 && g > 40 && b > 20 && r > g && r > b && yy > 50) {
        skin++;
      }
      final key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
      bins[key] = (bins[key] ?? 0) + 1;
    }
  }

  final mean = sum / total;
  final variance = math.max(0.0, sumSq / total - mean * mean);
  final skinRatio = skin / total;

  // كثافة الحواف
  var edges = 0;
  for (var y = 1; y < h - 1; y++) {
    for (var x = 1; x < w - 1; x++) {
      final i = y * w + x;
      final gx = gray[i + 1] - gray[i - 1];
      final gy = gray[i + w] - gray[i - w];
      if (gx.abs() + gy.abs() > 60) edges++;
    }
  }
  final edgeDensity = edges / total;

  var dominant = 0;
  for (final v in bins.values) {
    if (v > total * 0.004) dominant++;
  }

  ImageKind kind;
  if (dominant <= 28 && edgeDensity > 0.04) {
    kind = ImageKind.graphic;
  } else if (skinRatio >= 0.08) {
    kind = ImageKind.person;
  } else {
    kind = ImageKind.scene;
  }

  return ImageAnalysis(
    kind: kind,
    width: origW,
    height: origH,
    sharpness: sharpness,
    noise: noise,
    brightness: mean,
    contrast: math.sqrt(variance),
    skinRatio: skinRatio,
  );
}
