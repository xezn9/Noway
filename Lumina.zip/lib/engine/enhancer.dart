import 'dart:math' as math;
import 'dart:typed_data';

import 'package:image/image.dart' as img;

import 'analysis.dart';

class EnhanceRequest {
  const EnhanceRequest({
    required this.bytes,
    required this.scale,
    required this.strength,
    this.maxPixels = 12000000,
  });

  final Uint8List bytes;
  final int scale; // 1..4
  final double strength; // 0..1
  final int maxPixels;
}

class EnhanceResult {
  const EnhanceResult({
    required this.bytes,
    required this.width,
    required this.height,
    required this.appliedScale,
    required this.analysis,
  });

  final Uint8List bytes;
  final int width;
  final int height;
  final int appliedScale;
  final ImageAnalysis analysis;
}

class CloudPrep {
  const CloudPrep({
    required this.bytes,
    required this.kind,
    required this.width,
    required this.height,
  });

  final Uint8List bytes;
  final ImageKind kind;
  final int width;
  final int height;
}

int _ci(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

img.Image _decode(Uint8List bytes) {
  final decoded = img.decodeImage(bytes);
  if (decoded == null) {
    throw const FormatException('تعذر قراءة الصورة. جرّب صورة JPG أو PNG.');
  }
  return img.bakeOrientation(decoded);
}

/// تحليل فقط (لعرض نوع الصورة قبل المعالجة).
ImageAnalysis analyzeBytes(Uint8List bytes) => analyzeImage(_decode(bytes));

/// تجهيز الصورة لإرسالها للذكاء السحابي (تصغير + JPG).
CloudPrep prepareForCloud(Uint8List bytes) {
  final image = _decode(bytes);
  final analysis = analyzeImage(image);
  const maxSide = 1600;
  img.Image out = image;
  if (image.width >= image.height && image.width > maxSide) {
    out = img.copyResize(image,
        width: maxSide, interpolation: img.Interpolation.cubic);
  } else if (image.height > image.width && image.height > maxSide) {
    out = img.copyResize(image,
        height: maxSide, interpolation: img.Interpolation.cubic);
  }
  return CloudPrep(
    bytes: Uint8List.fromList(img.encodeJpg(out, quality: 92)),
    kind: analysis.kind,
    width: out.width,
    height: out.height,
  );
}

// ---------------------------------------------------------------------------
// أدوات المعالجة
// ---------------------------------------------------------------------------

/// تمويه صندوقي سريع (Separable) مع تكرار الحواف.
Uint8List _boxBlur(Uint8List src, int w, int h, int r) {
  if (r <= 0) return Uint8List.fromList(src);
  final tmp = Uint8List(w * h);
  final out = Uint8List(w * h);
  final win = 2 * r + 1;
  final half = win >> 1;

  // أفقي
  for (var y = 0; y < h; y++) {
    final row = y * w;
    var sum = 0;
    for (var k = -r; k <= r; k++) {
      sum += src[row + _ci(k, 0, w - 1)];
    }
    for (var x = 0; x < w; x++) {
      tmp[row + x] = (sum + half) ~/ win;
      final addX = _ci(x + r + 1, 0, w - 1);
      final subX = _ci(x - r, 0, w - 1);
      sum += src[row + addX] - src[row + subX];
    }
  }

  // عمودي (صف بصف لسرعة الذاكرة)
  final sums = Int32List(w);
  for (var k = -r; k <= r; k++) {
    final row = _ci(k, 0, h - 1) * w;
    for (var x = 0; x < w; x++) {
      sums[x] += tmp[row + x];
    }
  }
  for (var y = 0; y < h; y++) {
    final row = y * w;
    for (var x = 0; x < w; x++) {
      out[row + x] = (sums[x] + half) ~/ win;
    }
    final addRow = _ci(y + r + 1, 0, h - 1) * w;
    final subRow = _ci(y - r, 0, h - 1) * w;
    for (var x = 0; x < w; x++) {
      sums[x] += tmp[addRow + x] - tmp[subRow + x];
    }
  }
  return out;
}

Uint8List _luma(Uint8List r, Uint8List g, Uint8List b) {
  final out = Uint8List(r.length);
  for (var i = 0; i < r.length; i++) {
    out[i] = (299 * r[i] + 587 * g[i] + 114 * b[i]) ~/ 1000;
  }
  return out;
}

// ---------------------------------------------------------------------------
// المحرك الرئيسي
// ---------------------------------------------------------------------------

EnhanceResult enhanceBytes(EnhanceRequest req) {
  var image = _decode(req.bytes);
  final analysis = analyzeImage(image);

  // لا نتجاوز الحد الأقصى للبكسلات (حماية الذاكرة).
  if (image.width * image.height > req.maxPixels) {
    final f = math.sqrt(req.maxPixels / (image.width * image.height));
    image = img.copyResize(
      image,
      width: (image.width * f).floor(),
      height: (image.height * f).floor(),
      interpolation: img.Interpolation.average,
    );
  }

  var s = req.scale < 1 ? 1 : (req.scale > 4 ? 4 : req.scale);
  while (s > 1 && image.width * s * image.height * s > req.maxPixels) {
    s--;
  }

  final strength = req.strength < 0 ? 0.0 : (req.strength > 1 ? 1.0 : req.strength);

  // 1) تكبير بالاستيفاء التكعيبي
  final img.Image big = s > 1
      ? img.copyResize(
          image,
          width: image.width * s,
          height: image.height * s,
          interpolation: img.Interpolation.cubic,
        )
      : image;

  final w = big.width;
  final h = big.height;
  final n = w * h;

  // 2) استخراج القنوات
  final r = Uint8List(n);
  final g = Uint8List(n);
  final b = Uint8List(n);
  for (final p in big) {
    final idx = p.y * w + p.x;
    r[idx] = _ci(p.r.toInt(), 0, 255);
    g[idx] = _ci(p.g.toInt(), 0, 255);
    b[idx] = _ci(p.b.toInt(), 0, 255);
  }

  final isPerson = analysis.kind == ImageKind.person;
  final isGraphic = analysis.kind == ImageKind.graphic;

  // 3) إزالة الضوضاء مع الحفاظ على الحواف
  final noiseLevel = (analysis.noise / 6.0).clamp(0.0, 1.0).toDouble();
  var dn = noiseLevel * (0.5 + 0.5 * strength);
  if (isPerson) dn = math.min(1.0, dn * 1.25 + 0.05 * strength);
  if (isGraphic) dn *= 0.5;
  if (s >= 2) dn = math.max(dn, 0.12 * strength); // يخفف عيوب التكبير
  if (dn > 0.03) {
    final y0 = _luma(r, g, b);
    final dr = s >= 3 ? 2 : 1;
    final yb = _boxBlur(y0, w, h, dr);
    final edgeT = 10 + 22 * strength;
    final mask = Uint8List(n);
    for (var i = 0; i < n; i++) {
      final e = (y0[i] - yb[i]).abs();
      final wgt = e >= edgeT ? 0.0 : 1.0 - e / edgeT;
      mask[i] = (wgt * dn * 255).round();
    }
    for (final plane in [r, g, b]) {
      final pb = _boxBlur(plane, w, h, dr);
      for (var i = 0; i < n; i++) {
        final m = mask[i];
        if (m == 0) continue;
        plane[i] = plane[i] + ((pb[i] - plane[i]) * m) ~/ 255;
      }
    }
  }

  // 4) استعادة التفاصيل (Unsharp Mask متعدد المقاييس على الإضاءة فقط)
  final yS = _luma(r, g, b);
  final fineR = s >= 3 ? 2 : 1;
  final medR = 2 + 2 * s;
  final f1 = _boxBlur(_boxBlur(yS, w, h, fineR), w, h, fineR);
  final f2 = _boxBlur(_boxBlur(yS, w, h, medR), w, h, medR);

  var kind = 1.0;
  if (isPerson) kind = 0.7;
  if (isGraphic) kind = 1.15;
  final blurBoost = analysis.sharpness < 40 ? 1.35 : (analysis.sharpness < 180 ? 1.1 : 0.9);
  final a1 = (0.55 + 1.25 * strength) * kind * blurBoost;
  final a2 = (0.12 + 0.35 * strength) * (isPerson ? 0.6 : 1.0);
  final thr = 1.5 + analysis.noise * 0.7 * (1 - 0.5 * strength);

  for (var i = 0; i < n; i++) {
    var d1 = (yS[i] - f1[i]).toDouble();
    if (d1.abs() <= thr) {
      d1 = 0;
    } else {
      d1 = d1 > 0 ? d1 - thr : d1 + thr;
    }
    final d2 = (yS[i] - f2[i]).toDouble();
    var delta = a1 * d1 + a2 * d2;
    if (delta > 70) delta = 70;
    if (delta < -70) delta = -70;
    final di = delta.round();
    if (di == 0) continue;
    r[i] = _ci(r[i] + di, 0, 255);
    g[i] = _ci(g[i] + di, 0, 255);
    b[i] = _ci(b[i] + di, 0, 255);
  }

  // 5) الألوان والإضاءة (قوس تباين طبيعي + تشبع خفيف)
  final yT = _luma(r, g, b);
  final hist = List<int>.filled(256, 0);
  var lumSum = 0;
  for (var i = 0; i < n; i++) {
    hist[yT[i]]++;
    lumSum += yT[i];
  }
  final meanLum = lumSum / n;
  var lo = 0;
  var hi = 255;
  var acc = 0;
  for (var v = 0; v < 256; v++) {
    acc += hist[v];
    if (acc >= n * 0.004) {
      lo = v;
      break;
    }
  }
  acc = 0;
  for (var v = 255; v >= 0; v--) {
    acc += hist[v];
    if (acc >= n * 0.004) {
      hi = v;
      break;
    }
  }
  if (hi - lo < 60) {
    lo = 0;
    hi = 255;
  }
  final stretch = 0.75 * strength + 0.15;
  var gamma = 1.0;
  if (meanLum > 5 && meanLum < 250) {
    final target = 120.0;
    gamma = math.log(target / 255) / math.log(meanLum / 255);
    gamma = gamma.clamp(0.8, 1.25).toDouble();
    gamma = 1 + (gamma - 1) * (0.35 + 0.4 * strength);
  }
  final lut = Uint8List(256);
  for (var v = 0; v < 256; v++) {
    final base = v / 255.0;
    var t = ((v - lo) / (hi - lo)).clamp(0.0, 1.0).toDouble();
    t = base + (t - base) * stretch;
    t = math.pow(t, gamma).toDouble();
    final smooth = t * t * (3 - 2 * t);
    t = t + (smooth - t) * (0.30 * strength);
    lut[v] = _ci((t * 255).round(), 0, 255);
  }
  final sat = 1.0 + (isPerson ? 0.05 : 0.12) * strength;
  final satQ = (sat * 256).round();
  for (var i = 0; i < n; i++) {
    final rr = lut[r[i]];
    final gg = lut[g[i]];
    final bb = lut[b[i]];
    if (satQ == 256) {
      r[i] = rr;
      g[i] = gg;
      b[i] = bb;
    } else {
      final yy = (299 * rr + 587 * gg + 114 * bb) ~/ 1000;
      r[i] = _ci(yy + (((rr - yy) * satQ) >> 8), 0, 255);
      g[i] = _ci(yy + (((gg - yy) * satQ) >> 8), 0, 255);
      b[i] = _ci(yy + (((bb - yy) * satQ) >> 8), 0, 255);
    }
  }

  // 6) تجميع الناتج
  final rgb = Uint8List(n * 3);
  for (var i = 0, j = 0; i < n; i++, j += 3) {
    rgb[j] = r[i];
    rgb[j + 1] = g[i];
    rgb[j + 2] = b[i];
  }
  final out = img.Image.fromBytes(
    width: w,
    height: h,
    bytes: rgb.buffer,
    numChannels: 3,
  );
  final jpg = Uint8List.fromList(img.encodeJpg(out, quality: 95));

  return EnhanceResult(
    bytes: jpg,
    width: w,
    height: h,
    appliedScale: s,
    analysis: analysis,
  );
}
