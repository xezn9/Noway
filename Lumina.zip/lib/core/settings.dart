import 'package:shared_preferences/shared_preferences.dart';

class AppSettings {
  static const String _tokenKey = 'replicate_token';

  static Future<String> getToken() async {
    try {
      final p = await SharedPreferences.getInstance();
      return p.getString(_tokenKey) ?? '';
    } catch (_) {
      return '';
    }
  }

  static Future<void> setToken(String token) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_tokenKey, token.trim());
    } catch (_) {}
  }
}
