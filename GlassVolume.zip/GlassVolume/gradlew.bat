@echo off
set APP_HOME=%~dp0
set JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%JAR%" (
  powershell -Command "Invoke-WebRequest -Uri https://raw.githubusercontent.com/gradle/gradle/v8.13.0/gradle/wrapper/gradle-wrapper.jar -OutFile '%JAR%'"
)
java -Xmx64m -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
