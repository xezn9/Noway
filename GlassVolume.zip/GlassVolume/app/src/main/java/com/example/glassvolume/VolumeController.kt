package com.example.glassvolume

import android.content.Context
import android.media.AudioManager
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import kotlin.math.roundToInt

/** يمسك حالة الصوت + نمط الرنين + لقطة الشاشة اللي تنرسم خلف الزجاج */
class VolumeController(private val ctx: Context) {
    val audio: AudioManager = ctx.getSystemService(AudioManager::class.java)

    val streams = listOf(
        AudioManager.STREAM_MUSIC,
        AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION,
        AudioManager.STREAM_ALARM,
    )
    val levels = mutableStateMapOf<Int, Float>()
    var ringer by mutableIntStateOf(audio.ringerMode)
    var interaction by mutableIntStateOf(0)
    var dragging by mutableStateOf(false)
    var shot by mutableStateOf<ImageBitmap?>(null)

    init { refresh() }

    fun bump() { interaction++ }

    fun refresh() {
        streams.forEach { levels[it] = audio.getStreamVolume(it).toFloat() / audio.getStreamMaxVolume(it) }
        ringer = audio.ringerMode
        bump()
    }

    fun adjustMusic(direction: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0)
        refresh()
    }

    fun setLevel(stream: Int, fraction: Float) {
        val max = audio.getStreamMaxVolume(stream)
        levels[stream] = fraction
        try {
            audio.setStreamVolume(stream, (fraction * max).roundToInt().coerceIn(0, max), 0)
        } catch (_: SecurityException) { }
        ringer = audio.ringerMode
        bump()
    }

    /** زر واحد: مفتوح -> اهتزاز -> صامت -> مفتوح */
    fun cycleRinger() {
        val next = when (audio.ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
            AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        try {
            audio.ringerMode = next
        } catch (_: SecurityException) {
            audio.ringerMode = AudioManager.RINGER_MODE_NORMAL
            Toast.makeText(ctx, "فعّل صلاحية «عدم الإزعاج» للتطبيق حتى يشتغل الصامت", Toast.LENGTH_LONG).show()
        }
        refresh()
    }
}
