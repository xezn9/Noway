package com.example.glassvolume

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp, androidx.compose.ui.Alignment.CenterVertically),
                    ) {
                        Text("Glass Volume", style = MaterialTheme.typography.headlineMedium)
                        Text("1) فعّل خدمة «Glass Volume» من إعدادات الوصول. إذا النظام منعها: معلومات التطبيق ← ⋮ ← السماح بالإعدادات المقيّدة.")
                        Button(
                            onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("فتح إعدادات الوصول") }
                        Text("2) فعّل صلاحية «عدم الإزعاج» حتى يشتغل وضع الصامت.")
                        Button(
                            onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("فتح صلاحية عدم الإزعاج") }
                        Text("3) اضغط زر الصوت الفيزيائي وراح تطلع اللوحة.")
                    }
                }
            }
        }
    }
}
