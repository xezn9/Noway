package com.example.glassvolume

import android.media.AudioManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.rememberCanvasBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.delay
import kotlin.math.abs

/* ───────────── الزجاج: كل عنصر يستخدم نفس الـ backdrop (لقطة الشاشة) ───────────── */

fun Modifier.liquidGlass(
    backdrop: Backdrop,
    shape: Shape,
    tint: Color = Color.White.copy(alpha = 0.10f),
) = drawBackdrop(
    backdrop = backdrop,
    shape = { shape },
    effects = {
        vibrancy()
        blur(4.dp.toPx())
        lens(14.dp.toPx(), 26.dp.toPx())
    },
    onDrawSurface = { drawRect(tint) },
)

private fun streamIcon(stream: Int, level: Float): ImageVector = when (stream) {
    AudioManager.STREAM_MUSIC -> if (level <= 0f) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp
    AudioManager.STREAM_RING -> Icons.Rounded.Notifications
    AudioManager.STREAM_NOTIFICATION -> Icons.Rounded.Sms
    else -> Icons.Rounded.Alarm
}

private fun ringerName(mode: Int) = when (mode) {
    AudioManager.RINGER_MODE_NORMAL -> "رنين"
    AudioManager.RINGER_MODE_VIBRATE -> "اهتزاز"
    else -> "صامت"
}

private fun ringerIcon(mode: Int) = when (mode) {
    AudioManager.RINGER_MODE_NORMAL -> Icons.Rounded.Notifications
    AudioManager.RINGER_MODE_VIBRATE -> Icons.Rounded.Vibration
    else -> Icons.Rounded.NotificationsOff
}

/* ───────────── اللوحة الرئيسية ───────────── */

@Composable
fun VolumeOverlay(ctrl: VolumeController, onClosed: () -> Unit) {
    val backdrop = rememberCanvasBackdrop {
        val s = ctrl.shot
        if (s != null) drawImage(s) else drawRect(Color(0xFF2B2B30))
    }

    var visible by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    // فتح + إغلاق تلقائي (يتأجل مع أي لمس أو ضغط زر صوت)
    LaunchedEffect(ctrl.interaction, expanded, ctrl.dragging) {
        visible = true
        if (!ctrl.dragging) {
            delay(if (expanded) 6000 else 2500)
            visible = false
        }
    }

    // نابض مع ارتداد خفيف للدخول والخروج
    val p by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 450f),
        label = "panel",
        finishedListener = { if (!visible) onClosed() },
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            Modifier
                .fillMaxSize()
                // أي ضغطة خارج اللوحة = إغلاق بأنيميشن
                .pointerInput(Unit) { detectTapGestures { visible = false } }
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 14.dp)
                    .graphicsLayer {
                        alpha = p.coerceIn(0f, 1f)
                        val s = 0.78f + 0.22f * p
                        scaleX = s; scaleY = s
                        translationX = (1f - p) * 90.dp.toPx()
                        transformOrigin = TransformOrigin(1f, 0.5f)
                    }
                    .pointerInput(Unit) { detectTapGestures { } } // يمنع الإغلاق عند اللمس داخل اللوحة
            ) {
                AnimatedContent(
                    targetState = expanded,
                    transitionSpec = {
                        val origin = TransformOrigin(1f, 0.5f)
                        (fadeIn(spring(stiffness = 400f)) +
                            scaleIn(spring(0.7f, 300f), initialScale = 0.6f, transformOrigin = origin)) togetherWith
                            (fadeOut(spring(stiffness = 600f)) +
                                scaleOut(spring(0.8f, 400f), targetScale = 0.6f, transformOrigin = origin)) using
                            SizeTransform(clip = false)
                    },
                    label = "morph",
                ) { isExpanded ->
                    if (isExpanded) ExpandedCard(backdrop, ctrl) else CollapsedColumn(backdrop, ctrl) { expanded = true }
                }
            }
        }
    }
}

/* ───────────── الشكل المصغّر: سلايدر + زر الرنين + زر 3 نقاط ───────────── */

@Composable
private fun CollapsedColumn(backdrop: Backdrop, ctrl: VolumeController, onMore: () -> Unit) {
    var label by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(label) { if (label != null) { delay(1300); label = null } }

    val stream = AudioManager.STREAM_MUSIC
    val level = ctrl.levels[stream] ?: 0f

    Column(horizontalAlignment = Alignment.End) {
        Box(Modifier.align(Alignment.CenterHorizontally)) {
            GlassSlider(
                backdrop, level,
                onValueChange = { ctrl.setLevel(stream, it) },
                onDragging = { ctrl.dragging = it },
                width = 76.dp, height = 240.dp,
                icon = streamIcon(stream, level),
            )
        }
        Spacer(Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            AnimatedVisibility(
                visible = label != null,
                enter = fadeIn() + expandHorizontally(spring(0.6f, 400f), expandFrom = Alignment.End),
                exit = fadeOut() + shrinkHorizontally(shrinkTowards = Alignment.End),
            ) {
                Box(
                    Modifier
                        .padding(end = 10.dp)
                        .liquidGlass(backdrop, RoundedCornerShape(50), Color.White.copy(0.14f))
                        .padding(horizontal = 18.dp, vertical = 14.dp)
                ) { Text(label ?: "", color = Color.White, fontSize = 15.sp) }
            }
            GlassButton(backdrop, onClick = { ctrl.cycleRinger(); label = ringerName(ctrl.ringer) }) {
                Crossfade(ctrl.ringer, label = "ringer") { m ->
                    Icon(ringerIcon(m), null, tint = Color.White, modifier = Modifier.size(28.dp))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.align(Alignment.CenterHorizontally)) {
            GlassButton(backdrop, onClick = onMore) {
                Icon(Icons.Rounded.MoreHoriz, null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }
    }
}

/* ───────────── الشكل الموسّع: كل مستويات الصوت ───────────── */

@Composable
private fun ExpandedCard(backdrop: Backdrop, ctrl: VolumeController) {
    Column(
        Modifier
            .liquidGlass(backdrop, RoundedCornerShape(38.dp), Color.White.copy(0.12f))
            .padding(horizontal = 22.dp, vertical = 20.dp)
    ) {
        Text("الصوت", color = Color.White.copy(0.9f), fontSize = 14.sp, modifier = Modifier.padding(bottom = 14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            ctrl.streams.forEach { stream ->
                val level = ctrl.levels[stream] ?: 0f
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    GlassSlider(
                        backdrop, level,
                        onValueChange = { ctrl.setLevel(stream, it) },
                        onDragging = { ctrl.dragging = it },
                        width = 52.dp, height = 210.dp,
                    )
                    Spacer(Modifier.height(14.dp))
                    Icon(streamIcon(stream, level), null, tint = Color.White, modifier = Modifier.size(26.dp))
                }
            }
        }
    }
}

/* ───────────── زر زجاجي: يكبر ويرتد عند الضغط ───────────── */

@Composable
private fun GlassButton(backdrop: Backdrop, onClick: () -> Unit, content: @Composable () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 1.2f else 1f, spring(0.45f, 450f), label = "btn")
    Box(
        Modifier
            .size(64.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .liquidGlass(backdrop, CircleShape, Color.White.copy(if (pressed) 0.24f else 0.10f))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { onClick() },
                )
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/* ───────────── سلايدر زجاجي عمودي مثل iOS ─────────────
   - يتضخم أثناء السحب
   - يتمطّط (rubber-band) إذا سحبت أبعد من الحد وبعدين يرجع بنابض
   - التعبئة بيضاء مثل الفيديو */

@Composable
fun GlassSlider(
    backdrop: Backdrop,
    value: Float,
    onValueChange: (Float) -> Unit,
    onDragging: (Boolean) -> Unit,
    width: Dp,
    height: Dp,
    icon: ImageVector? = null,
) {
    var dragging by remember { mutableStateOf(false) }
    var overshoot by remember { mutableFloatStateOf(0f) }

    val grow by animateFloatAsState(if (dragging) 1.1f else 1f, spring(0.5f, 380f), label = "grow")
    val stretch by animateFloatAsState(overshoot, spring(0.4f, 300f), label = "stretch")
    val fill by animateFloatAsState(
        value,
        if (dragging) snap() else spring(stiffness = Spring.StiffnessMedium),
        label = "fill",
    )

    val shape = RoundedCornerShape(percent = 50)
    Box(
        Modifier
            .size(width, height)
            .graphicsLayer {
                scaleX = grow * (1f - abs(stretch) * 0.06f)
                scaleY = grow + abs(stretch) * 0.25f
                transformOrigin = TransformOrigin(0.5f, if (stretch > 0f) 1f else 0f)
            }
            .liquidGlass(backdrop, shape)
            .clip(shape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    dragging = true; onDragging(true)

                    fun apply(y: Float) {
                        val raw = 1f - y / size.height
                        onValueChange(raw.coerceIn(0f, 1f))
                        overshoot = when {
                            raw > 1f -> (raw - 1f).coerceAtMost(0.5f)
                            raw < 0f -> raw.coerceAtLeast(-0.5f)
                            else -> 0f
                        }
                    }
                    apply(down.position.y)
                    do {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.first()
                        if (c.pressed) { apply(c.position.y); c.consume() }
                    } while (ev.changes.any { it.pressed })

                    dragging = false; overshoot = 0f; onDragging(false)
                }
            }
    ) {
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(fill.coerceIn(0f, 1f))
                .background(Color.White.copy(alpha = 0.95f))
        )
        if (icon != null) {
            Icon(
                icon, null,
                tint = if (fill > 0.14f) Color.Black.copy(0.55f) else Color.White,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp).size(26.dp),
            )
        }
    }
}
