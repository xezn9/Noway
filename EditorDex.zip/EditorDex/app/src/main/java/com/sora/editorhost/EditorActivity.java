package com.sora.editorhost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import io.github.rosemoe.sora.event.ContentChangeEvent;
import io.github.rosemoe.sora.lang.EmptyLanguage;
import io.github.rosemoe.sora.langs.java.JavaLanguage;
import io.github.rosemoe.sora.widget.CodeEditor;
import io.github.rosemoe.sora.widget.EditorSearcher;
import io.github.rosemoe.sora.widget.schemes.SchemeDarcula;

/**
 * محرر نصوص كامل مبني على Sora Editor، الواجهة كلها بالكود (بدون XML ولا موارد)
 * حتى ينضاف لأي تطبيق جاهز بدون ما يتعارض مع الـ resources تبعه.
 *
 * الاستدعاء:
 *   EditorActivity.open(context, "/sdcard/file.txt");
 * أو Intent عادي:
 *   intent.putExtra("path", "/sdcard/file.txt");   أو   intent.setData(uri);
 */
public class EditorActivity extends Activity {

    public static final String EXTRA_PATH = "path";

    public static void open(Context ctx, String path) {
        Intent i = new Intent(ctx, EditorActivity.class);
        i.putExtra(EXTRA_PATH, path);
        if (!(ctx instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        ctx.startActivity(i);
    }

    private static final int BG = 0xFF1E1E1E;
    private static final int BAR = 0xFF2B2B2B;

    private CodeEditor editor;
    private LinearLayout searchBar;
    private EditText findInput;
    private EditText replaceInput;

    private String path;
    private Uri uri;
    private boolean modified = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent in = getIntent();
        path = in.getStringExtra(EXTRA_PATH);
        if (path == null && in.getData() != null) {
            uri = in.getData();
            if ("file".equals(uri.getScheme())) {
                path = uri.getPath();
                uri = null;
            }
        }

        String name = "بدون اسم";
        if (path != null) {
            name = new File(path).getName();
        } else if (uri != null && uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
        }

        buildUi(name);
        applyLanguage(name);
        loadFile();
    }

    // ---------------------------------------------------------------- UI

    private void buildUi(String name) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);

        // الشريط العلوي
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(BAR);
        top.setPadding(dp(8), 0, dp(4), 0);

        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        top.addView(button("↶", v -> editor.undo()));
        top.addView(button("↷", v -> editor.redo()));
        top.addView(button("بحث", v -> toggleSearch()));
        top.addView(button("حفظ", v -> save()));
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        // شريط البحث والاستبدال
        searchBar = new LinearLayout(this);
        searchBar.setOrientation(LinearLayout.VERTICAL);
        searchBar.setBackgroundColor(BAR);
        searchBar.setPadding(dp(8), 0, dp(4), dp(4));
        searchBar.setVisibility(View.GONE);

        LinearLayout row1 = new LinearLayout(this);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        findInput = input("بحث...");
        findInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { doSearch(); }
        });
        row1.addView(findInput, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row1.addView(button("▲", v -> {
            if (editor.getSearcher().hasQuery()) editor.getSearcher().gotoPrevious();
        }));
        row1.addView(button("▼", v -> {
            if (editor.getSearcher().hasQuery()) editor.getSearcher().gotoNext();
        }));
        searchBar.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        replaceInput = input("استبدال بـ...");
        row2.addView(replaceInput, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row2.addView(button("استبدال", v -> {
            if (editor.getSearcher().hasQuery())
                editor.getSearcher().replaceCurrentMatch(replaceInput.getText().toString());
        }));
        row2.addView(button("الكل", v -> {
            if (editor.getSearcher().hasQuery())
                editor.getSearcher().replaceAll(replaceInput.getText().toString());
        }));
        searchBar.addView(row2);

        root.addView(searchBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // المحرر نفسه
        editor = new CodeEditor(this);
        editor.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        editor.setColorScheme(new SchemeDarcula());
        editor.setTypefaceText(Typeface.MONOSPACE);
        editor.setTextSize(14f);
        editor.setLineNumberEnabled(true);
        editor.setWordwrap(false);
        editor.subscribeEvent(ContentChangeEvent.class, (event, unsubscribe) -> modified = true);
        root.addView(editor, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setOnClickListener(l);
        return b;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF888888);
        e.setTextColor(Color.WHITE);
        e.setTextSize(14);
        e.setSingleLine(true);
        e.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        return e;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- لغة المحرر

    private void applyLanguage(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".java")) {
            editor.setEditorLanguage(new JavaLanguage());   // دائماً كائن جديد
        } else {
            editor.setEditorLanguage(new EmptyLanguage());
        }
    }

    // ---------------------------------------------------------------- بحث

    private void toggleSearch() {
        if (searchBar.getVisibility() == View.VISIBLE) {
            searchBar.setVisibility(View.GONE);
            editor.getSearcher().stopSearch();
        } else {
            searchBar.setVisibility(View.VISIBLE);
            findInput.requestFocus();
        }
    }

    private void doSearch() {
        String q = findInput.getText().toString();
        if (q.length() == 0) {
            editor.getSearcher().stopSearch();
            return;
        }
        // (تجاهل حالة الأحرف = true ، regex = false)
        editor.getSearcher().search(q, new EditorSearcher.SearchOptions(true, false));
    }

    // ---------------------------------------------------------------- فتح وحفظ

    private void loadFile() {
        if (path == null && uri == null) return;   // ملف جديد فاضي
        new Thread(() -> {
            try {
                InputStream is = (path != null)
                        ? new FileInputStream(path)
                        : getContentResolver().openInputStream(uri);
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = is.read(buf)) > 0) {
                    bos.write(buf, 0, n);
                }
                is.close();
                final String text = bos.toString("UTF-8");
                runOnUiThread(() -> {
                    editor.setText(text);
                    editor.post(() -> modified = false);
                });
            } catch (final Exception e) {
                runOnUiThread(() -> toast("فشل فتح الملف: " + e.getMessage()));
            }
        }).start();
    }

    private boolean save() {
        if (path == null && uri == null) {
            toast("ما في ملف محدد للحفظ");
            return false;
        }
        try {
            byte[] data = editor.getText().toString().getBytes("UTF-8");
            OutputStream os = (path != null)
                    ? new FileOutputStream(path)
                    : getContentResolver().openOutputStream(uri, "wt");
            os.write(data);
            os.close();
            modified = false;
            toast("تم الحفظ");
            return true;
        } catch (Exception e) {
            toast("فشل الحفظ: " + e.getMessage());
            return false;
        }
    }

    // ---------------------------------------------------------------- رجوع

    @Override
    public void onBackPressed() {
        if (searchBar.getVisibility() == View.VISIBLE) {
            toggleSearch();
            return;
        }
        if (!modified) {
            finish();
            return;
        }
        new AlertDialog.Builder(this)
                .setMessage("في تعديلات غير محفوظة، تريد تحفظ؟")
                .setPositiveButton("حفظ", (d, w) -> { if (save()) finish(); })
                .setNegativeButton("تجاهل", (d, w) -> finish())
                .setNeutralButton("إلغاء", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (editor != null) editor.release();
    }
}
