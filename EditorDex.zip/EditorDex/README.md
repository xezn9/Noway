# EditorDex — محرر نصوص (Sora Editor) للدمج بتطبيق جاهز

## 1) البناء
ارفع المشروع على GitHub ← تبويب Actions ← "Build Editor DEX" ← Run workflow.
بعد ما يخلص نزّل الـ artifact باسم `editor-dex`، يحتوي ملفات `classes.dex` (وممكن `classes2.dex`...).

## 2) الدمج بالتطبيق الهدف (MT Manager)
- افتح الـ APK بـ MT Manager.
- شوف آخر رقم dex موجود (مثلاً classes3.dex) وضيف ملفات الـ dex تبعتي بعده:
  `classes.dex` ← `classes4.dex` ، `classes2.dex` ← `classes5.dex` وهكذا.
  (لا تبدّل ولا تكتب فوق dex الأصلي.)

## 3) سجّل الـ Activity بـ AndroidManifest.xml (داخل <application>)
```xml
<activity
    android:name="com.sora.editorhost.EditorActivity"
    android:exported="false"
    android:theme="@android:style/Theme.Material.NoActionBar"
    android:windowSoftInputMode="adjustResize"
    android:configChanges="orientation|screenSize|keyboardHidden" />
```

## 4) افتح المحرر من تطبيقك
بأي مكان بالـ smali (داخل method عندها `Context` مثل `p0`، و`v0` لازم يكون register فاضي، زوّد `.locals` إذا لزم):
```smali
const-string v0, "/storage/emulated/0/test.txt"
invoke-static {p0, v0}, Lcom/sora/editorhost/EditorActivity;->open(Landroid/content/Context;Ljava/lang/String;)V
```
أو بـ Intent عادي: `new Intent().setClassName(pkg, "com.sora.editorhost.EditorActivity")` مع extra باسم `path`، أو `setData(uri)`.

## 5) وقّع الـ APK وثبّته.

## ملاحظات
- التلوين مفعّل لملفات `.java`، والباقي نص عادي مع أرقام أسطر. لتلوين XML/JSON/Smali نضيف TextMate.
- المحرر يقرأ ويكتب الملف بصلاحيات التطبيق الهدف نفسه (لازم يكون عنده صلاحية الوصول للملف).
- إذا طلع تعارض بكلاسات androidx بين الـ dex الجديد والأصلي، احذف الكلاسات المكررة من الـ dex الجديد.
- المكتبة ترخيصها LGPL 2.1: اذكر Sora Editor وترخيصها بالتطبيق.
