package com.example.pdfglass

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** نقاط الرسم مُطبَّعة على عرض الصفحة (x/w , y/w) */
data class Ink(val pts: List<Pair<Float, Float>>, val argb: Int, val width: Float, val highlight: Boolean)

class PdfEngine private constructor(
    private val renderer: PdfRenderer,
    private val pfd: android.os.ParcelFileDescriptor,
    val sizes: List<Pair<Int, Int>>,
) {
    private val mutex = Mutex()
    val pageCount get() = sizes.size

    suspend fun render(index: Int, targetWidth: Int): Bitmap = mutex.withLock {
        withContext(Dispatchers.IO) {
            renderer.openPage(index).use { p ->
                val h = (targetWidth.toFloat() * p.height / p.width).toInt()
                val bmp = Bitmap.createBitmap(targetWidth, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            }
        }
    }

    /** يحفظ PDF جديد (الصفحات + التعليقات مدموجة كصور) */
    suspend fun export(ctx: Context, inks: Map<Int, List<Ink>>, out: Uri) {
        val doc = PdfDocument()
        for (i in 0 until pageCount) {
            val (w, h) = sizes[i]
            val bmp = render(i, 1600)
            val page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, i + 1).create())
            val c = page.canvas
            c.drawBitmap(bmp, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
            inks[i].orEmpty().forEach { ink ->
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
                    color = ink.argb; alpha = if (ink.highlight) 100 else 255
                    strokeWidth = ink.width * w
                }
                val path = Path()
                ink.pts.forEachIndexed { k, (x, y) -> if (k == 0) path.moveTo(x * w, y * w) else path.lineTo(x * w, y * w) }
                if (ink.pts.size == 1) path.lineTo(ink.pts[0].first * w + 0.1f, ink.pts[0].second * w)
                c.drawPath(path, paint)
            }
            doc.finishPage(page)
            bmp.recycle()
        }
        withContext(Dispatchers.IO) {
            ctx.contentResolver.openOutputStream(out)?.use { doc.writeTo(it) }
            doc.close()
        }
    }

    fun close() { runCatching { renderer.close(); pfd.close() } }

    companion object {
        suspend fun open(ctx: Context, uri: Uri): PdfEngine = withContext(Dispatchers.IO) {
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")!!
            val r = PdfRenderer(pfd)
            val sizes = (0 until r.pageCount).map { r.openPage(it).use { p -> p.width to p.height } }
            PdfEngine(r, pfd, sizes)
        }
    }
}
