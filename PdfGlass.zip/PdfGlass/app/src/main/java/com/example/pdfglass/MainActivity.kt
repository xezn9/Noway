package com.example.pdfglass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.launch

enum class Tool { Hand, Pen, Highlighter, Eraser }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

/** سطح زجاجي سائل فوق المحتوى */
fun Modifier.glass(backdrop: LayerBackdrop, shape: androidx.compose.ui.graphics.Shape, tint: Float = 0.16f) =
    this.drawBackdrop(
        backdrop = backdrop,
        shape = { shape },
        effects = {
            vibrancy()
            blur(6.dp.toPx())
            lens(16.dp.toPx(), 32.dp.toPx())
        },
        onDrawSurface = { drawRect(Color.White.copy(alpha = tint)) },
    )

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var engine by remember { mutableStateOf<PdfEngine?>(null) }
    val inks = remember { mutableStateMapOf<Int, List<Ink>>() }
    val history = remember { mutableStateListOf<Int>() }
    var tool by remember { mutableStateOf(Tool.Hand) }
    var color by remember { mutableStateOf(Color(0xFFFF3B30)) }
    var saving by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            engine?.close(); inks.clear(); history.clear(); tool = Tool.Hand
            engine = PdfEngine.open(ctx, uri)
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch { saving = true; engine?.export(ctx, inks.toMap(), uri); saving = false }
    }

    val bg = Brush.verticalGradient(listOf(Color(0xFF1B2A4A), Color(0xFF3B1F5C), Color(0xFF0F3D3E)))
    val backdrop = rememberLayerBackdrop()

    Box(Modifier.fillMaxSize()) {
        // المحتوى الذي ينكسر خلف الزجاج
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop).background(bg)) {
            val e = engine
            if (e != null) {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 120.dp, bottom = 210.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    userScrollEnabled = tool == Tool.Hand,
                ) {
                    itemsIndexed(e.sizes) { i, (w, h) ->
                        PageView(
                            index = i, engine = e, aspect = w.toFloat() / h, tool = tool, color = color,
                            inks = inks[i].orEmpty(),
                            onAdd = { inks[i] = inks[i].orEmpty() + it; history += i },
                            onErase = { x, y ->
                                inks[i] = inks[i].orEmpty().filterNot { ink ->
                                    ink.pts.any { (px, py) -> (px - x) * (px - x) + (py - y) * (py - y) < 0.0009f }
                                }
                            },
                        )
                    }
                }
            }
        }

        if (engine == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.glass(backdrop, RoundedCornerShape(32.dp)).clickable { openLauncher.launch(arrayOf("application/pdf")) }
                        .padding(horizontal = 36.dp, vertical = 22.dp)
                ) { Text("افتح ملف PDF", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color.White) }
            }
        }

        // الشريط العلوي
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp)
                .glass(backdrop, RoundedCornerShape(28.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            GlassChip("📂 فتح", false) { openLauncher.launch(arrayOf("application/pdf")) }
            Text(if (saving) "جارٍ الحفظ…" else "PDF Glass", color = Color.White, fontWeight = FontWeight.Bold)
            GlassChip("💾 حفظ", false) { if (engine != null && !saving) saveLauncher.launch("annotated.pdf") }
        }

        // شريط الأدوات السفلي
        if (engine != null) Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(12.dp)
                .glass(backdrop, RoundedCornerShape(32.dp)).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (tool == Tool.Pen || tool == Tool.Highlighter) Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                listOf(0xFFFF3B30, 0xFFFFCC00, 0xFF0A84FF, 0xFF30D158, 0xFF000000).forEach { c ->
                    val col = Color(c)
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(col)
                            .border(if (col == color) 3.dp else 1.dp, Color.White, CircleShape)
                            .clickable { color = col }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GlassChip("✋", tool == Tool.Hand) { tool = Tool.Hand }
                GlassChip("✏️", tool == Tool.Pen) { tool = Tool.Pen }
                GlassChip("🖍", tool == Tool.Highlighter) { tool = Tool.Highlighter }
                GlassChip("🧽", tool == Tool.Eraser) { tool = Tool.Eraser }
                GlassChip("↩︎", false) {
                    history.removeLastOrNull()?.let { p -> inks[p] = inks[p].orEmpty().dropLast(1) }
                }
            }
        }
    }
}

@Composable
fun GlassChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) Color.White.copy(alpha = 0.35f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 16.sp) }
}

@Composable
fun PageView(
    index: Int, engine: PdfEngine, aspect: Float, tool: Tool, color: Color,
    inks: List<Ink>, onAdd: (Ink) -> Unit, onErase: (Float, Float) -> Unit,
) {
    var bmp by remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(index) { bmp = engine.render(index, 1080).asImageBitmap() }
    var live by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var width by remember { mutableFloatStateOf(1f) }
    val hl = tool == Tool.Highlighter
    val strokeW = if (hl) 0.025f else 0.005f

    Box(
        Modifier.fillMaxWidth().aspectRatio(aspect).shadow(10.dp, RoundedCornerShape(6.dp))
            .background(Color.White).onSizeChanged { width = it.width.toFloat() }
            .pointerInput(tool, color) {
                if (tool == Tool.Hand) return@pointerInput
                detectDragGestures(
                    onDragStart = { if (tool == Tool.Eraser) onErase(it.x / width, it.y / width) else live = listOf(it) },
                    onDrag = { ch, _ ->
                        ch.consume()
                        if (tool == Tool.Eraser) onErase(ch.position.x / width, ch.position.y / width)
                        else live = live + ch.position
                    },
                    onDragEnd = {
                        if (live.isNotEmpty()) onAdd(Ink(live.map { it.x / width to it.y / width }, color.toArgb(), strokeW, hl))
                        live = emptyList()
                    },
                    onDragCancel = { live = emptyList() },
                )
            }
    ) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize()) }
        Canvas(Modifier.fillMaxSize()) {
            fun draw(pts: List<Offset>, c: Color, w: Float, h: Boolean) {
                if (pts.isEmpty()) return
                val p = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) }; if (pts.size == 1) lineTo(pts[0].x + 0.1f, pts[0].y) }
                drawPath(p, c.copy(alpha = if (h) 0.4f else 1f), style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            inks.forEach { i -> draw(i.pts.map { Offset(it.first * size.width, it.second * size.width) }, Color(i.argb), i.width * size.width, i.highlight) }
            draw(live, color, strokeW * size.width, hl)
        }
    }
}
