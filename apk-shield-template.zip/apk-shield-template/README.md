# APK Shield Template (Android / Kotlin)

This is a minimal Android project demonstrating **source-build hardening** with R8. The release build shrinks and obfuscates the project's own compiled Java/Kotlin code.

## Build in GitHub Actions

1. Create a GitHub repository and upload these project files (extract the ZIP first).
2. Push to `main` or `master`, or open **Actions → Build Android project → Run workflow**.
3. Download the generated APK from the workflow run's **Artifacts** section.

GitHub checks out the repository files directly, so a workflow does not need to unzip the project archive.

## Build locally

Install JDK 17 and Gradle 8.9, then run:

```bash
gradle assembleDebug
gradle assembleRelease
```

The release APK is written to `app/build/outputs/apk/release/`.

## Important limitation

This is **not** a universal APK-to-`.so` packer. R8 protects code while compiling from the original source project. It cannot reliably convert an arbitrary prebuilt APK's Java/Kotlin classes into native `.so` libraries. A universal repacker must account for each app's manifest, resources, reflection, JNI, multidex, signatures, and runtime loading behavior; there is no generic guarantee that repacking will preserve app behavior.

Use this template for apps you own or are authorized to modify. For stronger protection, combine R8 with server-side secrets/business logic and carefully tested native code for selected sensitive components.
