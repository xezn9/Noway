package com.example.apkshield

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(12, 20, 34))
        }
        val title = TextView(this).apply {
            text = "APK Shield"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val body = TextView(this).apply {
            text = "Build-time hardening template\\n\\nRelease builds use R8 to shrink and obfuscate this project's own code.\\n\\nFor best protection, build from the original Java/Kotlin source."
            textSize = 16f
            setTextColor(Color.rgb(190, 205, 225))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(body)
        setContentView(root)
    }
}
