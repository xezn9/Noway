# Add narrowly-scoped keep rules only for classes accessed via reflection,
# JNI, serialization, or framework conventions. Avoid broad keep rules.

# Example for a class whose exact name is required by JNI:
# -keep class com.example.app.NativeBridge { *; }
