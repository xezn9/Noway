# Keep rules for release builds (minify is disabled by default)
