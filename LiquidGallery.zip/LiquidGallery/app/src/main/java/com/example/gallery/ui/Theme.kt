package com.example.gallery.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val LocalIsDark = staticCompositionLocalOf { false }

private val DarkColors = darkColorScheme(
    primary = Color(0xFF0091FF),
    background = Color(0xFF0B0F14),
    surface = Color(0xFF161C24),
    surfaceVariant = Color(0xFF1E2630),
    onBackground = Color(0xFFF2F4F7),
    onSurface = Color(0xFFF2F4F7),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0088FF),
    background = Color(0xFFF4F5F7),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE6E9EE),
    onBackground = Color(0xFF14181F),
    onSurface = Color(0xFF14181F),
)

@Composable
fun GalleryTheme(dark: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalIsDark provides dark) {
        MaterialTheme(
            colorScheme = if (dark) DarkColors else LightColors,
            content = content
        )
    }
}

fun backgroundBrush(dark: Boolean): Brush =
    if (dark) Brush.verticalGradient(listOf(Color(0xFF121A26), Color(0xFF0B0F14)))
    else Brush.verticalGradient(listOf(Color(0xFFF9FAFC), Color(0xFFEBEFF4)))
