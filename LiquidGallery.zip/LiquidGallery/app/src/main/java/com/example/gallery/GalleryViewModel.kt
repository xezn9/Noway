package com.example.gallery

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.gallery.data.MediaItem
import com.example.gallery.data.MediaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("gallery_prefs", Context.MODE_PRIVATE)

    var media by mutableStateOf<List<MediaItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set

    var favorites by mutableStateOf(
        prefs.getStringSet("favorites", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
    )
        private set
    var columns by mutableIntStateOf(prefs.getInt("columns", 3))
        private set
    var showVideos by mutableStateOf(prefs.getBoolean("show_videos", true))
        private set

    /** 0 = system, 1 = light, 2 = dark */
    var themeMode by mutableIntStateOf(prefs.getInt("theme_mode", 0))
        private set

    fun refresh() {
        viewModelScope.launch {
            loading = true
            media = withContext(Dispatchers.IO) { MediaRepository.load(getApplication()) }
            loading = false
        }
    }

    fun toggleFavorite(id: Long) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit().putStringSet("favorites", favorites.map { it.toString() }.toSet()).apply()
    }

    fun updateColumns(value: Int) {
        columns = value
        prefs.edit().putInt("columns", value).apply()
    }

    fun updateShowVideos(value: Boolean) {
        showVideos = value
        prefs.edit().putBoolean("show_videos", value).apply()
    }

    fun updateThemeMode(value: Int) {
        themeMode = value
        prefs.edit().putInt("theme_mode", value).apply()
    }
}
