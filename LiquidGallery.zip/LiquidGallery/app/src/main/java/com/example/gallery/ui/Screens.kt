package com.example.gallery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.example.gallery.GalleryViewModel
import com.example.gallery.R
import com.example.gallery.data.Album

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(40.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            color = MaterialTheme.colorScheme.onBackground.copy(0.6f),
            textAlign = TextAlign.Center,
            fontSize = 15.sp
        )
    }
}

@Composable
fun PermissionScreen(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(36.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Rounded.PhotoLibrary, null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(72.dp)
        )
        Text(
            stringResource(R.string.permission_title),
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            stringResource(R.string.permission_body),
            color = MaterialTheme.colorScheme.onBackground.copy(0.65f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp, bottom = 24.dp)
        )
        Button(onClick = onGrant) { Text(stringResource(R.string.grant_access)) }
    }
}

@Composable
fun AlbumsGrid(albums: List<Album>, onOpen: (Album) -> Unit) {
    if (albums.isEmpty()) {
        EmptyState(stringResource(R.string.empty_photos))
        return
    }
    val context = LocalContext.current
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = gridContentPadding().let {
            androidx.compose.foundation.layout.PaddingValues(
                start = 14.dp, end = 14.dp,
                top = it.calculateTopPadding() + 6.dp,
                bottom = it.calculateBottomPadding()
            )
        },
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        items(albums, key = { it.id }) { album ->
            val request = remember(album.cover.uri) {
                ImageRequest.Builder(context).data(album.cover.uri).crossfade(true).build()
            }
            Column(Modifier.clickable { onOpen(album) }) {
                AsyncImage(
                    model = request,
                    contentDescription = album.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Text(
                    album.name,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 6.dp, top = 8.dp)
                )
                Text(
                    stringResource(R.string.items_count, album.count),
                    color = MaterialTheme.colorScheme.onBackground.copy(0.55f),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(start = 6.dp)
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: GalleryViewModel) {
    val top = gridContentPadding().calculateTopPadding()
    val bottom = gridContentPadding().calculateBottomPadding()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = top + 6.dp, bottom = bottom),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SettingsCard(stringResource(R.string.settings_grid)) {
            Text(stringResource(R.string.settings_columns), color = MaterialTheme.colorScheme.onSurface)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (2..5).forEach { n ->
                    FilterChip(
                        selected = vm.columns == n,
                        onClick = { vm.updateColumns(n) },
                        label = { Text(n.toString()) }
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(stringResource(R.string.settings_videos), color = MaterialTheme.colorScheme.onSurface)
                Switch(checked = vm.showVideos, onCheckedChange = vm::updateShowVideos)
            }
        }

        SettingsCard(stringResource(R.string.settings_theme)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    R.string.theme_system to 0,
                    R.string.theme_light to 1,
                    R.string.theme_dark to 2,
                ).forEach { (label, mode) ->
                    FilterChip(
                        selected = vm.themeMode == mode,
                        onClick = { vm.updateThemeMode(mode) },
                        label = { Text(stringResource(label)) }
                    )
                }
            }
        }

        SettingsCard(stringResource(R.string.settings_about)) {
            Text(
                stringResource(R.string.settings_about_body),
                color = MaterialTheme.colorScheme.onSurface.copy(0.7f)
            )
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(
                title,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 10.dp)
            )
            content()
        }
    }
}
