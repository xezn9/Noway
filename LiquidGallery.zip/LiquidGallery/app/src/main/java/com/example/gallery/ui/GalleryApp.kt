package com.example.gallery.ui

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.gallery.GalleryViewModel
import com.example.gallery.R
import com.example.gallery.data.Album
import com.example.gallery.data.MediaItem
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.catalog.components.LiquidBottomTab
import com.kyant.backdrop.catalog.components.LiquidBottomTabs

private data class TabSpec(val icon: ImageVector, val label: Int)

private val Tabs = listOf(
    TabSpec(Icons.Rounded.PhotoLibrary, R.string.tab_photos),
    TabSpec(Icons.Rounded.Collections, R.string.tab_albums),
    TabSpec(Icons.Rounded.Favorite, R.string.tab_favorites),
    TabSpec(Icons.Rounded.Settings, R.string.tab_settings),
)

private class ViewerState(val items: List<MediaItem>, val index: Int)

@Composable
fun GalleryApp(vm: GalleryViewModel) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (vm.themeMode) {
        1 -> false
        2 -> true
        else -> systemDark
    }
    GalleryTheme(dark) { GalleryContent(vm, dark) }
}

@Composable
private fun GalleryContent(vm: GalleryViewModel, dark: Boolean) {
    val context = LocalContext.current
    val activity = LocalActivity.current as? ComponentActivity
    val backdrop = rememberLayerBackdrop()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var openAlbumId by rememberSaveable { mutableLongStateOf(NO_ALBUM) }
    var viewer by remember { mutableStateOf<ViewerState?>(null) }

    // ---- Permission ---------------------------------------------------------------------------
    var granted by remember { mutableStateOf(hasMediaPermission(context)) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        granted = hasMediaPermission(context)
        if (granted) vm.refresh()
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasMediaPermission(context)
        if (granted) vm.refresh()
    }

    // ---- Edge-to-edge system bars follow the theme (the viewer is always dark) ---------------------
    val barsDark = dark || viewer != null
    DisposableEffect(barsDark) {
        val style = SystemBarStyle.auto(
            android.graphics.Color.TRANSPARENT,
            android.graphics.Color.TRANSPARENT
        ) { barsDark }
        activity?.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        onDispose { }
    }

    // ---- Derived data ------------------------------------------------------------------------
    val media = remember(vm.media, vm.showVideos) {
        if (vm.showVideos) vm.media else vm.media.filter { !it.isVideo }
    }
    val albums = remember(media) {
        media.groupBy { it.bucketId }.map { (id, list) ->
            Album(id, list.first().bucketName, list.first(), list.size)
        }
    }
    val favoriteItems = remember(media, vm.favorites) { media.filter { it.id in vm.favorites } }
    val openAlbum = albums.firstOrNull { it.id == openAlbumId }
    val albumItems = remember(media, openAlbumId) { media.filter { it.bucketId == openAlbumId } }

    // ---- Delete ------------------------------------------------------------------------------
    val deleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewer = null
            vm.refresh()
        }
    }
    fun requestDelete(item: MediaItem) {
        if (Build.VERSION.SDK_INT >= 30) {
            val pending = MediaStore.createDeleteRequest(context.contentResolver, listOf(item.uri))
            deleteLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
        } else {
            try {
                context.contentResolver.delete(item.uri, null, null)
                viewer = null
                vm.refresh()
            } catch (_: Exception) {
                Toast.makeText(context, R.string.delete_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- Back handling -----------------------------------------------------------------------
    BackHandler(enabled = tab == 1 && openAlbum != null) { openAlbumId = NO_ALBUM }
    BackHandler(enabled = viewer != null) { viewer = null }

    val photosTitle = stringResource(R.string.tab_photos)
    val albumsTitle = stringResource(R.string.tab_albums)
    val favoritesTitle = stringResource(R.string.tab_favorites)
    val settingsTitle = stringResource(R.string.tab_settings)

    Box(Modifier.fillMaxSize()) {
        // Everything the glass can see through lives inside this layer.
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(backdrop)
                .background(backgroundBrush(dark))
        ) {
            if (!granted) {
                PermissionScreen(onGrant = { permissionLauncher.launch(mediaPermissions()) })
            } else when (tab) {
                0 -> MediaGrid(
                    items = media,
                    columns = vm.columns,
                    favorites = vm.favorites,
                    grouped = true,
                    emptyText = stringResource(R.string.empty_photos),
                    onOpen = { viewer = ViewerState(media, it) }
                )

                1 -> if (openAlbum == null) {
                    AlbumsGrid(albums, onOpen = { openAlbumId = it.id })
                } else {
                    MediaGrid(
                        items = albumItems,
                        columns = vm.columns,
                        favorites = vm.favorites,
                        grouped = false,
                        emptyText = stringResource(R.string.empty_photos),
                        onOpen = { viewer = ViewerState(albumItems, it) }
                    )
                }

                2 -> MediaGrid(
                    items = favoriteItems,
                    columns = vm.columns,
                    favorites = vm.favorites,
                    grouped = false,
                    emptyText = stringResource(R.string.empty_favorites),
                    onOpen = { viewer = ViewerState(favoriteItems, it) }
                )

                else -> SettingsScreen(vm)
            }
        }

        // Floating glass header
        if (granted) {
            val (title, count) = when (tab) {
                0 -> photosTitle to media.size.toString()
                1 -> if (openAlbum != null) openAlbum.name to albumItems.size.toString()
                else albumsTitle to albums.size.toString()
                2 -> favoritesTitle to favoriteItems.size.toString()
                else -> settingsTitle to null
            }
            GlassHeader(
                backdrop = backdrop,
                title = title,
                subtitle = count,
                modifier = Modifier.align(Alignment.TopStart),
                leading = if (tab == 1 && openAlbum != null) {
                    {
                        GlassIconButton(
                            backdrop,
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            stringResource(R.string.back),
                            onClick = { openAlbumId = NO_ALBUM }
                        )
                    }
                } else null
            )
        }

        // Liquid glass bottom tabs (copied from the Backdrop Catalog)
        val tabContentColor = if (dark) Color.White else Color(0xFF1B1B1F)
        LiquidBottomTabs(
            selectedTabIndex = { tab },
            onTabSelected = {
                if (it != tab) openAlbumId = NO_ALBUM
                tab = it
            },
            backdrop = backdrop,
            tabsCount = Tabs.size,
            darkTheme = dark,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp, vertical = 14.dp)
        ) {
            Tabs.forEachIndexed { index, spec ->
                LiquidBottomTab(onClick = {
                    if (index != tab) openAlbumId = NO_ALBUM
                    tab = index
                }) {
                    Icon(
                        spec.icon,
                        contentDescription = null,
                        tint = tabContentColor,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        stringResource(spec.label),
                        color = tabContentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                }
            }
        }

        // Full-screen viewer
        viewer?.let { state ->
            ViewerScreen(
                items = state.items,
                startIndex = state.index,
                favorites = vm.favorites,
                onToggleFavorite = { vm.toggleFavorite(it.id) },
                onClose = { viewer = null },
                onShare = { shareItem(context, it) },
                onDelete = { requestDelete(it) },
                onPlay = { playVideo(context, it) },
            )
        }
    }
}

private const val NO_ALBUM = Long.MIN_VALUE

private fun mediaPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
    )
    Build.VERSION.SDK_INT >= 33 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
    )
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

private fun hasMediaPermission(context: Context): Boolean {
    fun granted(p: String) =
        ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED
    return when {
        Build.VERSION.SDK_INT >= 34 ->
            granted(Manifest.permission.READ_MEDIA_IMAGES) ||
                granted(Manifest.permission.READ_MEDIA_VIDEO) ||
                granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 ->
            granted(Manifest.permission.READ_MEDIA_IMAGES) ||
                granted(Manifest.permission.READ_MEDIA_VIDEO)
        else -> granted(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
}

private fun shareItem(context: Context, item: MediaItem) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = item.mime.ifBlank { if (item.isVideo) "video/*" else "image/*" }
        putExtra(Intent.EXTRA_STREAM, item.uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, null))
}

private fun playVideo(context: Context, item: MediaItem) {
    val view = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(item.uri, item.mime.ifBlank { "video/*" })
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(view)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, R.string.play_video, Toast.LENGTH_SHORT).show()
    }
}
