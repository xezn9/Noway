package com.example.gallery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.example.gallery.R
import com.example.gallery.data.MediaItem
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/** Space reserved above/below the grid for the floating glass header and bottom tabs. */
@Composable
fun gridContentPadding(): PaddingValues {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 76.dp
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 124.dp
    return PaddingValues(start = 2.dp, end = 2.dp, top = top, bottom = bottom)
}

@Composable
fun MediaGrid(
    items: List<MediaItem>,
    columns: Int,
    favorites: Set<Long>,
    grouped: Boolean,
    emptyText: String,
    onOpen: (index: Int) -> Unit,
) {
    if (items.isEmpty()) {
        EmptyState(emptyText)
        return
    }

    val zone = remember { ZoneId.systemDefault() }
    val sections: List<Pair<LocalDate?, List<IndexedValue<MediaItem>>>> = remember(items, grouped) {
        if (grouped) {
            items.withIndex()
                .groupBy { LocalDate.ofInstant(Instant.ofEpochSecond(it.value.dateAdded), zone) }
                .toList()
        } else {
            listOf(null to items.withIndex().toList())
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        modifier = Modifier.fillMaxSize(),
        contentPadding = gridContentPadding(),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        sections.forEach { (date, list) ->
            if (date != null) {
                item(key = "header-$date", span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        dateLabel(date),
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 6.dp)
                    )
                }
            }
            items(list, key = { it.value.id }) { (index, item) ->
                MediaCell(
                    item = item,
                    favorite = item.id in favorites,
                    onClick = { onOpen(index) }
                )
            }
        }
    }
}

@Composable
private fun dateLabel(date: LocalDate): String {
    val today = LocalDate.now()
    return when (date) {
        today -> stringResource(R.string.today)
        today.minusDays(1) -> stringResource(R.string.yesterday)
        else -> date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG))
    }
}

@Composable
fun MediaCell(item: MediaItem, favorite: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val request = remember(item.uri) {
        ImageRequest.Builder(context).data(item.uri).crossfade(true).build()
    }
    Box(
        modifier
            .aspectRatio(1f)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = request,
            contentDescription = item.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (item.isVideo) {
            Icon(
                Icons.Rounded.PlayCircle, null,
                tint = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(6.dp)
                    .size(22.dp)
                    .shadow(4.dp, androidx.compose.foundation.shape.CircleShape)
            )
        }
        if (favorite) {
            Icon(
                Icons.Rounded.Favorite, null,
                tint = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .size(18.dp)
            )
        }
    }
}
